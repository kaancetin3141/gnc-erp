// Demo veri üretimi — GNC CRM
// 2 şirket, 8 kullanıcı, 30 müşteri, 100 aktivite, leads, deals, tasks, 3 maps araması

import { db } from './db'
import { getRolePermissions } from './rbac'
import { mockMapsSearch } from './maps-mock'

const FIRST_NAMES = ['Mehmet', 'Ayşe', 'Mustafa', 'Fatma', 'Ahmet', 'Emine', 'Ali', 'Zeynep', 'Hüseyin', 'Hatice', 'İbrahim', 'Elif', 'Hasan', 'Meryem', 'Murat', 'Sultan']
const LAST_NAMES = ['Yılmaz', 'Kaya', 'Demir', 'Şahin', 'Çelik', 'Yıldız', 'Yıldırım', 'Öztürk', 'Aydın', 'Özdemir', 'Arslan', 'Doğan', 'Kılıç', 'Aslan', 'Çetin', 'Kara']

const COMPANY_SUFFIXES = ['A.Ş.', 'Ltd. Şti.', 'San. Tic.', 'Grup', 'Holding']
const COMPANY_PREFIXES = [
  'Anadolu', 'Marmara', 'Ege', 'Akdeniz', 'Karadeniz', 'İstanbul', 'Başkent',
  'Boğaziçi', 'Çamlıca', 'Uludağ', 'Toros', 'Kapadokya', 'Pamukkale', 'Nemrut',
  'Yıldız', 'Demir', 'Altın', 'Gümüş', 'Kristal', 'Safir', 'Zümrüt', 'Yakut',
]

const SECTORS = ['Sağlık', 'Diş Sağlığı', 'Güzellik & Bakım', 'Restoran & Kafe', 'Perakende', 'E-Ticaret', 'İnşaat & Gayrimenkul', 'Otomotiv', 'Eğitim', 'Teknoloji & Yazılım', 'Finans & Muhasebe', 'Hukuk', 'Lojistik & Taşımacılık', 'Üretim', 'Turizm & Otelcilik']

const CITIES = ['İstanbul', 'Ankara', 'İzmir', 'Bursa', 'Antalya', 'Adana', 'Konya', 'Gaziantep']

const STREETS = ['Atatürk Bulvarı', 'Cumhuriyet Caddesi', 'Gazi Caddesi', 'İnönü Caddesi', 'Fatih Caddesi', 'Mithatpaşa Caddesi', 'Halitpaşa Caddesi', 'Zafer Caddesi']

const TAG_POOL = ['VIP Müşteri', 'Yıllık Sözleşme', 'Ödeme Problemi', 'Teklif Bekliyor', 'Yeni Müşteri', 'Sadık', 'Referans', 'Sıcak Lead', 'Soğuk Lead', 'Fırsat']

function rand<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}

function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function randomName(): string {
  return `${rand(FIRST_NAMES)} ${rand(LAST_NAMES)}`
}

function randomCompanyName(): string {
  return `${rand(COMPANY_PREFIXES)} ${rand(COMPANY_SUFFIXES)}`
}

function randomPhone(): string {
  return `+90 5${randInt(3, 5)}${randInt(0, 9)} ${randInt(100, 999)} ${randInt(10, 99)} ${randInt(10, 99)}`
}

function randomEmail(name: string): string {
  const slug = name.toLowerCase()
    .replace('ı', 'i').replace('ş', 's').replace('ç', 'c')
    .replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o')
    .replace(/[^a-z0-9]/g, '.')
  return `${slug}@${rand(['gmail.com', 'outlook.com', 'hotmail.com', 'yandex.com'])}`
}

function daysAgo(days: number): Date {
  const d = new Date()
  d.setDate(d.getDate() - days)
  d.setHours(randInt(8, 18), randInt(0, 59))
  return d
}

function daysFromNow(days: number): Date {
  const d = new Date()
  d.setDate(d.getDate() + days)
  return d
}

export async function runSeed(): Promise<{ success: boolean; message: string; counts: Record<string, number> }> {
  // Önce temizle — bağımlılık sırasına göre
  // Kafe ERP
  await db.cafeOrderItem.deleteMany()
  await db.cafePayment.deleteMany()
  await db.cafeOrder.deleteMany()
  await db.menuItem.deleteMany()
  await db.menuCategory.deleteMany()
  await db.cafeTable.deleteMany()
  await db.cafe.deleteMany()
  // ERP
  await db.productionItem.deleteMany()
  await db.invoiceLine.deleteMany()
  await db.invoice.deleteMany()
  await db.quoteLine.deleteMany()
  await db.quote.deleteMany()
  await db.orderTrackingStep.deleteMany()
  await db.order.deleteMany()
  await db.stockMovement.deleteMany()
  await db.product.deleteMany()
  await db.messageTemplate.deleteMany()
  await db.tenantSetting.deleteMany()
  // CRM
  await db.task.deleteMany()
  await db.note.deleteMany()
  await db.activity.deleteMany()
  await db.deal.deleteMany()
  await db.contact.deleteMany()
  await db.lead.deleteMany()
  await db.mapsSearch.deleteMany()
  await db.attachment.deleteMany()
  await db.message.deleteMany()
  await db.customer.deleteMany()
  await db.tag.deleteMany()
  await db.auditLog.deleteMany()
  await db.user.deleteMany()
  await db.tenant.deleteMany()

  // === TENANTS ===
  const tenant1 = await db.tenant.create({
    data: {
      name: 'Anadolu Satış A.Ş.',
      plan: 'enterprise',
      defaultCurrency: 'TRY',
      country: 'TR',
    },
  })
  const tenant2 = await db.tenant.create({
    data: {
      name: 'Ege Ticaret Ltd. Şti.',
      plan: 'business',
      defaultCurrency: 'TRY',
      country: 'TR',
    },
  })

  // === USERS ===
  // Tenant 1: Admin, 2 Müdür, 4 Temsilci
  const t1Admin = await db.user.create({
    data: {
      tenantId: tenant1.id,
      email: 'demo@anadolu.com',
      name: 'Demir Yıldız',
      role: 'admin',
      permissions: JSON.stringify(getRolePermissions('admin')),
      status: 'active',
      title: 'Satış Direktörü',
      phone: '+90 532 111 22 33',
    },
  })

  const t1Manager1 = await db.user.create({
    data: {
      tenantId: tenant1.id,
      email: 'ayse.kaya@anadolu.com',
      name: 'Ayşe Kaya',
      role: 'manager',
      permissions: JSON.stringify(getRolePermissions('manager')),
      managerId: t1Admin.id,
      status: 'active',
      title: 'Satış Müdürü',
      phone: '+90 533 222 33 44',
    },
  })

  const t1Manager2 = await db.user.create({
    data: {
      tenantId: tenant1.id,
      email: 'mustafa.demir@anadolu.com',
      name: 'Mustafa Demir',
      role: 'manager',
      permissions: JSON.stringify(getRolePermissions('manager')),
      managerId: t1Admin.id,
      status: 'active',
      title: 'Bölge Satış Müdürü',
      phone: '+90 534 333 44 55',
    },
  })

  const t1Reps = []
  const repNames1 = ['Zeynep Arslan', 'Ahmet Çelik', 'Elif Şahin', 'Burak Öztürk']
  const repTitles1 = ['Satış Temsilcisi', 'Kıdemli Satış Temsilcisi', 'Satış Temsilcisi', 'Satış Temsilcisi']
  for (let i = 0; i < repNames1.length; i++) {
    const manager = i < 2 ? t1Manager1 : t1Manager2
    const u = await db.user.create({
      data: {
        tenantId: tenant1.id,
        email: randomEmail(repNames1[i]),
        name: repNames1[i],
        role: 'rep',
        permissions: JSON.stringify(getRolePermissions('rep')),
        managerId: manager.id,
        status: 'active',
        title: repTitles1[i],
        phone: randomPhone(),
      },
    })
    t1Reps.push(u)
  }

  // Tenant 2: Admin, 1 Müdür, 2 Temsilci
  const t2Admin = await db.user.create({
    data: {
      tenantId: tenant2.id,
      email: 'demo@egeticaret.com',
      name: 'Hakan Aydın',
      role: 'admin',
      permissions: JSON.stringify(getRolePermissions('admin')),
      status: 'active',
      title: 'Genel Müdür',
      phone: '+90 535 444 55 66',
    },
  })

  const t2Manager = await db.user.create({
    data: {
      tenantId: tenant2.id,
      email: 'selin.kara@egeticaret.com',
      name: 'Selin Kara',
      role: 'manager',
      permissions: JSON.stringify(getRolePermissions('manager')),
      managerId: t2Admin.id,
      status: 'active',
      title: 'Satış Müdürü',
      phone: '+90 536 555 66 77',
    },
  })

  const t2Reps = []
  const repNames2 = ['Okan Yıldırım', 'Deniz Aslan']
  for (const name of repNames2) {
    const u = await db.user.create({
      data: {
        tenantId: tenant2.id,
        email: randomEmail(name),
        name,
        role: 'rep',
        permissions: JSON.stringify(getRolePermissions('rep')),
        managerId: t2Manager.id,
        status: 'active',
        title: 'Satış Temsilcisi',
        phone: randomPhone(),
      },
    })
    t2Reps.push(u)
  }

  // === CAFE-ERP: Kafe rolleri (kasa/barmen/komi) — Tenant 1'e bağlı ===
  const t1Kasa = await db.user.create({
    data: {
      tenantId: tenant1.id,
      email: 'kasa@anadolu.com',
      name: 'Selin Demir',
      role: 'kasa',
      permissions: JSON.stringify(getRolePermissions('kasa')),
      status: 'active',
      title: 'Kasiyer',
      phone: randomPhone(),
    },
  })
  const t1Barmen = await db.user.create({
    data: {
      tenantId: tenant1.id,
      email: 'barmen@anadolu.com',
      name: 'Burak Yıldız',
      role: 'barmen',
      permissions: JSON.stringify(getRolePermissions('barmen')),
      status: 'active',
      title: 'Barmen',
      phone: randomPhone(),
    },
  })
  const t1Komi = await db.user.create({
    data: {
      tenantId: tenant1.id,
      email: 'komi@anadolu.com',
      name: 'Hülya Aydın',
      role: 'komi',
      permissions: JSON.stringify(getRolePermissions('komi')),
      status: 'active',
      title: 'Komi (Garson)',
      phone: randomPhone(),
    },
  })
  void t1Kasa; void t1Barmen; void t1Komi

  // === TAGS ===
  for (const tenant of [tenant1, tenant2]) {
    for (const tag of TAG_POOL) {
      await db.tag.create({
        data: {
          tenantId: tenant.id,
          name: tag,
          color: ['amber', 'emerald', 'red', 'sky', 'violet', 'rose', 'orange', 'teal'][randInt(0, 7)],
        },
      })
    }
  }

  // === CUSTOMERS (30) ===
  const allRepsT1 = [t1Admin, t1Manager1, t1Manager2, ...t1Reps]
  const allRepsT2 = [t2Admin, t2Manager, ...t2Reps]

  const customers = []
  for (let i = 0; i < 20; i++) {
    const owner = rand(allRepsT1)
    const lastActivityDays = randInt(0, 60)
    const c = await db.customer.create({
      data: {
        tenantId: tenant1.id,
        name: randomCompanyName(),
        sector: rand(SECTORS),
        segment: rand(['vip', 'kurumsal', 'standart', 'potansiyel']),
        ownerId: owner.id,
        source: rand(['manuel', 'google_maps', 'referral', 'website', 'event']),
        address: `${rand(STREETS)} No:${randInt(1, 200)}`,
        city: rand(CITIES),
        country: 'TR',
        phone: randomPhone(),
        email: `info@${rand(COMPANY_PREFIXES).toLowerCase()}.com.tr`,
        web: `www.${rand(COMPANY_PREFIXES).toLowerCase()}.com.tr`,
        taxNumber: String(randInt(1000000000, 9999999999)),
        status: rand(['aktif', 'aktif', 'aktif', 'pasif', 'potansiyel']),
        tags: JSON.stringify(randInt(0, 3) === 0 ? [] : Array.from({ length: randInt(1, 3) }, () => rand(TAG_POOL))),
        kvkkConsent: Math.random() > 0.3,
        kvkkConsentAt: Math.random() > 0.3 ? daysAgo(randInt(1, 300)) : null,
        annualRevenue: randInt(1, 50) * 100000,
        employeeCount: randInt(5, 500),
        lastActivityAt: daysAgo(lastActivityDays),
        createdAt: daysAgo(randInt(30, 365)),
      },
    })
    customers.push(c)

    // Her müşteriye 1-3 contact
    const contactCount = randInt(1, 3)
    for (let j = 0; j < contactCount; j++) {
      await db.contact.create({
        data: {
          customerId: c.id,
          name: randomName(),
          position: rand(['Genel Müdür', 'Satış Müdürü', 'Muhasebe Müdürü', 'Satın Alma Uzmanı', 'İK Müdürü', 'Pazarlama Müdürü']),
          email: randomEmail(randomName()),
          phone: randomPhone(),
          isPrimary: j === 0,
        },
      })
    }
  }

  for (let i = 0; i < 10; i++) {
    const owner = rand(allRepsT2)
    const lastActivityDays = randInt(0, 60)
    const c = await db.customer.create({
      data: {
        tenantId: tenant2.id,
        name: randomCompanyName(),
        sector: rand(SECTORS),
        segment: rand(['vip', 'kurumsal', 'standart', 'potansiyel']),
        ownerId: owner.id,
        source: rand(['manuel', 'google_maps', 'referral', 'website']),
        address: `${rand(STREETS)} No:${randInt(1, 200)}`,
        city: rand(CITIES),
        country: 'TR',
        phone: randomPhone(),
        email: `info@${rand(COMPANY_PREFIXES).toLowerCase()}.com.tr`,
        web: `www.${rand(COMPANY_PREFIXES).toLowerCase()}.com.tr`,
        taxNumber: String(randInt(1000000000, 9999999999)),
        status: rand(['aktif', 'aktif', 'potansiyel']),
        tags: JSON.stringify(randInt(0, 3) === 0 ? [] : Array.from({ length: randInt(1, 2) }, () => rand(TAG_POOL))),
        kvkkConsent: Math.random() > 0.3,
        kvkkConsentAt: Math.random() > 0.3 ? daysAgo(randInt(1, 300)) : null,
        annualRevenue: randInt(1, 30) * 100000,
        employeeCount: randInt(5, 200),
        lastActivityAt: daysAgo(lastActivityDays),
        createdAt: daysAgo(randInt(30, 365)),
      },
    })
    customers.push(c)

    const contactCount = randInt(1, 2)
    for (let j = 0; j < contactCount; j++) {
      await db.contact.create({
        data: {
          customerId: c.id,
          name: randomName(),
          position: rand(['Genel Müdür', 'Satış Müdürü', 'Muhasebe Müdürü']),
          email: randomEmail(randomName()),
          phone: randomPhone(),
          isPrimary: j === 0,
        },
      })
    }
  }

  // === ACTIVITIES (100) ===
  const t1Customers = customers.filter((c) => c.tenantId === tenant1.id)
  const activityTypes = ['arama', 'toplanti', 'email', 'whatsapp', 'not', 'ziyaret']
  const outcomes = ['basarili', 'basarisiz', 'ertelendi', 'callback']
  const activitySubjects = {
    arama: ['Giriş araması', 'Teklif takip araması', 'Randevu onay araması', 'Ödeme hatırlatma', 'İhtiyaç analizi'],
    toplanti: ['Tanışma toplantısı', 'Teklif sunumu', 'Sözleşme görüşmesi', 'Çeyrek değerlendirme', 'Ürün demo'],
    email: ['Teklif gönderildi', 'Bilgi talebi', 'Sözleşme taslağı', 'Fatura gönderildi', 'Teşekkür maili'],
    whatsapp: ['Randevu hatırlatma', 'Fiyat listesi', 'Belge paylaşımı', 'Onay mesajı'],
    not: ['Müşteri geri bildirimi', 'Karar verici değişti', 'Bütçe onayı bekleniyor', 'Rakip teklif karşılaştırması'],
    ziyaret: ['Saha ziyareti', 'İmza ziyareti', 'Teslimat ziyareti', 'İlişki geliştirme ziyareti'],
  }

  for (let i = 0; i < 100; i++) {
    const type = rand(activityTypes)
    const customer = rand(t1Customers)
    const owner = allRepsT1.find((u) => u.id === customer.ownerId) ?? t1Admin
    await db.activity.create({
      data: {
        tenantId: tenant1.id,
        customerId: customer.id,
        type,
        subject: rand(activitySubjects[type as keyof typeof activitySubjects]),
        detail: Math.random() > 0.5 ? 'Görüşme detayları burada...' : null,
        date: daysAgo(randInt(0, 90)),
        durationMin: type === 'toplanti' ? randInt(30, 120) : type === 'ziyaret' ? randInt(60, 180) : randInt(5, 30),
        outcome: type === 'not' ? null : rand(outcomes),
        userId: owner.id,
      },
    })
  }

  // === DEALS (25) ===
  const stages = ['yeni', 'iletisim', 'teklif', 'muzakere', 'kazanıldı', 'kaybedildi']
  for (let i = 0; i < 25; i++) {
    const customer = rand(t1Customers)
    const stage = rand(stages)
    const owner = allRepsT1.find((u) => u.id === customer.ownerId) ?? t1Admin
    const value = randInt(5, 500) * 1000
    await db.deal.create({
      data: {
        tenantId: tenant1.id,
        title: `${customer.name} - ${rand(['Yıllık Sözleşme', 'Proje Satışı', 'Ürün Tedariği', 'Hizmet Paketi', 'Danışmanlık'])}`,
        customerId: customer.id,
        value,
        currency: 'TRY',
        stage,
        probability: stage === 'kazanıldı' ? 100 : stage === 'kaybedildi' ? 0 : randInt(10, 80),
        expectedCloseDate: daysFromNow(randInt(-30, 90)),
        ownerId: owner.id,
        lossReason: stage === 'kaybedildi' ? rand(['Fiyat çok yüksek', 'Rakibi tercih etti', 'Bütçe yok', 'Zamanlama uygun değil']) : null,
        lossNote: stage === 'kaybedildi' ? 'Müşteri rakip firmayı tercih etti.' : null,
        createdAt: daysAgo(randInt(1, 60)),
      },
    })
  }

  // === TASKS (20) ===
  const priorities = ['dusuk', 'orta', 'yuksek', 'acil']
  const taskTitles = [
    'Müşteriyi ara', 'Teklif hazırla', 'Toplantı planla', 'Fatura gönder',
    'Sözleşme gönder', 'Demo planla', 'Geri arama yap', 'Bilgi gönder',
    'Fiyat güncelle', 'İlişki geliştirme ziyareti',
  ]
  for (let i = 0; i < 20; i++) {
    const customer = rand(t1Customers)
    const assignee = allRepsT1.find((u) => u.id === customer.ownerId) ?? t1Admin
    const isOverdue = Math.random() > 0.5
    await db.task.create({
      data: {
        tenantId: tenant1.id,
        title: rand(taskTitles),
        description: Math.random() > 0.5 ? 'Detaylı açıklama...' : null,
        dueDate: isOverdue ? daysAgo(randInt(1, 15)) : daysFromNow(randInt(0, 30)),
        assigneeId: assignee.id,
        customerId: customer.id,
        priority: rand(priorities),
        reminderTime: '09:00',
        status: isOverdue && Math.random() > 0.7 ? 'tamamlandi' : 'acik',
        autoGenerated: Math.random() > 0.7,
        completedAt: isOverdue && Math.random() > 0.7 ? daysAgo(randInt(0, 5)) : null,
      },
    })
  }

  // === NOTES (30) ===
  const noteContents = [
    'Müşteri çok ilgili, teklifi inceliyor.',
    'Bütçe sorunumuz var, taksitlendirme istiyor.',
    'Karar verici önümüzdeki hafta dönüyor.',
    'Rakip firmadan da teklif almış.',
    'Yıllık sözleşme yenileme zamanı yaklaştı.',
    'Ürün demosunu beğendi, satın alma sürecini başlatacak.',
    'Fiyat pazarlığı yapıyor, %10 indirim istiyor.',
    'Mevcut tedarikçi ile sözleşmesi var, 3 ay sonra bitiyor.',
  ]
  for (let i = 0; i < 30; i++) {
    const customer = rand(t1Customers)
    const owner = allRepsT1.find((u) => u.id === customer.ownerId) ?? t1Admin
    await db.note.create({
      data: {
        customerId: customer.id,
        userId: owner.id,
        content: rand(noteContents),
        isPinned: Math.random() > 0.8,
        createdAt: daysAgo(randInt(0, 60)),
      },
    })
  }

  // === MAPS SEARCHES + LEADS ===
  const searches = [
    { query: 'diş kliniği', city: 'İstanbul', tenantId: tenant1.id, userId: t1Reps[0].id },
    { query: 'kuaför', city: 'İzmir', tenantId: tenant1.id, userId: t1Reps[1].id },
    { query: 'restoran', city: 'Ankara', tenantId: tenant1.id, userId: t1Reps[2].id },
  ]

  for (const s of searches) {
    const results = mockMapsSearch({ query: s.query, city: s.city })
    const ms = await db.mapsSearch.create({
      data: {
        tenantId: s.tenantId,
        userId: s.userId,
        query: s.query,
        city: s.city,
        country: 'TR',
        radius: 10,
        resultCount: results.length,
        importedCount: randInt(3, 8),
      },
    })
    // Bazı sonuçları lead olarak aktar
    const toImport = results.slice(0, randInt(3, 8))
    for (const r of toImport) {
      await db.lead.create({
        data: {
          tenantId: s.tenantId,
          name: r.name,
          placeId: r.placeId,
          category: r.category,
          address: r.address,
          city: r.city,
          country: 'TR',
          lat: r.lat,
          lng: r.lng,
          phone: r.phone,
          web: r.web,
          rating: r.rating,
          reviewCount: r.reviewCount,
          ownerId: s.userId,
          source: 'google_maps',
          status: rand(['yeni', 'yeni', 'iletisim', 'nitelikli', 'kaybedildi']),
          notes: JSON.stringify([]),
          mapsSearchId: ms.id,
          createdAt: daysAgo(randInt(0, 20)),
        },
      })
    }
  }

  // === AUDIT LOGS ===
  for (let i = 0; i < 10; i++) {
    await db.auditLog.create({
      data: {
        tenantId: tenant1.id,
        actorId: rand(allRepsT1).id,
        action: rand(['create', 'update', 'login', 'export']),
        entity: rand(['customer', 'deal', 'activity', 'session']),
        entityId: rand(customers).id,
        before: JSON.stringify({ status: 'eski' }),
        after: JSON.stringify({ status: 'yeni' }),
        createdAt: daysAgo(randInt(0, 30)),
      },
    })
  }

  // === FAZ 2 ÖRNEK ÜRÜNLER ===
  const products = [
    { name: 'CRM Standart Paket', sku: 'CRM-STD', price: 15000, stock: 100 },
    { name: 'CRM Pro Paket', sku: 'CRM-PRO', price: 35000, stock: 50 },
    { name: 'ERP Modülü', sku: 'ERP-01', price: 50000, stock: 30 },
    { name: 'Danışmanlık (Saat)', sku: 'CONS-1H', price: 1500, stock: 999 },
  ]
  for (const p of products) {
    await db.product.create({
      data: {
        tenantId: tenant1.id,
        name: p.name,
        sku: p.sku,
        price: p.price,
        currency: 'TRY',
        taxRate: 20,
        stock: p.stock,
        minStock: 10,
        unit: 'adet',
        category: 'Yazılım',
      },
    })
  }

  // ============================================================
  // CAFE-ERP — Demo kafe verisi
  // ============================================================
  // Kafe 1
  const cafe1 = await db.cafe.create({
    data: {
      tenantId: tenant1.id,
      name: 'Boğaziçi Kafe',
      address: 'Beşiktaş, İstanbul',
      phone: '+90 212 555 10 20',
      tableCount: 0,
    },
  })

  // Kafe 2 — farklı lokasyon (multi-cafe test)
  const cafe2 = await db.cafe.create({
    data: {
      tenantId: tenant1.id,
      name: 'Kadıköy Teras Kafe',
      address: 'Kadıköy, İstanbul',
      phone: '+90 216 555 30 40',
      tableCount: 0,
    },
  })

  // Masa düzeni (kuş bakışı) — cafe1 için 8 masa
  const tableShapes = ['square', 'round', 'rectangle', 'square', 'round', 'square', 'rectangle', 'round']
  const tablePositions = [
    { x: 20, y: 25 }, { x: 50, y: 25 }, { x: 80, y: 25 },
    { x: 20, y: 50 }, { x: 50, y: 50 }, { x: 80, y: 50 },
    { x: 30, y: 80 }, { x: 70, y: 80 },
  ]
  for (let i = 0; i < 8; i++) {
    await db.cafeTable.create({
      data: {
        cafeId: cafe1.id,
        number: `M${i + 1}`,
        shape: tableShapes[i],
        x: tablePositions[i].x,
        y: tablePositions[i].y,
        width: tableShapes[i] === 'rectangle' ? 14 : 10,
        height: 10,
        capacity: tableShapes[i] === 'rectangle' ? 6 : 4,
        status: i === 0 ? 'siparis' : i === 1 ? 'dolu' : 'bos',
      },
    })
  }
  await db.cafe.update({ where: { id: cafe1.id }, data: { tableCount: 8 } })

  // cafe2 için 5 masa
  for (let i = 0; i < 5; i++) {
    await db.cafeTable.create({
      data: {
        cafeId: cafe2.id,
        number: `T${i + 1}`,
        shape: i % 2 === 0 ? 'round' : 'square',
        x: 25 + (i % 3) * 25,
        y: 30 + Math.floor(i / 3) * 30,
        width: 10, height: 10,
        capacity: 4, status: 'bos',
      },
    })
  }
  await db.cafe.update({ where: { id: cafe2.id }, data: { tableCount: 5 } })

  // Menü — kafe 1 için kategoriler ve ürünler
  const catBar = await db.menuCategory.create({
    data: { cafeId: cafe1.id, name: 'Sıcak İçecekler', icon: '☕', sortOrder: 0 },
  })
  const catCold = await db.menuCategory.create({
    data: { cafeId: cafe1.id, name: 'Soğuk İçecekler', icon: '🥤', sortOrder: 1 },
  })
  const catFood = await db.menuCategory.create({
    data: { cafeId: cafe1.id, name: 'Ana Yemekler', icon: '🍽️', sortOrder: 2 },
  })
  const catDessert = await db.menuCategory.create({
    data: { cafeId: cafe1.id, name: 'Tatlılar', icon: '🍰', sortOrder: 3 },
  })

  const menuItems = [
    // Bar
    { cat: catBar, name: 'Espresso', price: 45, station: 'bar', prepTime: 5, recipe: '1 shot espresso çek. Küçük fincanda servis et.' },
    { cat: catBar, name: 'Cappuccino', price: 60, station: 'bar', prepTime: 7, recipe: '1 shot espresso + 150ml süt köpüğü. Kakao tozu serpin.' },
    { cat: catBar, name: 'Latte', price: 65, station: 'bar', prepTime: 7, recipe: '1 shot espresso + 200ml süt + ince köpük. Latte art opsiyonel.' },
    { cat: catBar, name: 'Türk Kahvesi', price: 50, station: 'bar', prepTime: 8, recipe: 'Cezvede 2 fincan su + 2 tatlı kaşığı kahve. Kaynat, köpük ile servis et.' },
    { cat: catBar, name: 'Sıcak Çikolata', price: 70, station: 'bar', prepTime: 6, recipe: '200ml süt + 2 yemek kaşığı kakao + şeker. Karıştırarak ısıt.' },
    // Cold drinks (bar)
    { cat: catCold, name: 'Ice Latte', price: 75, station: 'bar', prepTime: 7, recipe: '1 shot espresso + buz + 200ml soğuk süt. Vanilya şurubu ekle.' },
    { cat: catCold, name: 'Limonata', price: 55, station: 'bar', prepTime: 5, recipe: 'Taze limon suyu + su + şeker + nane yaprağı. Buz ile servis et.' },
    { cat: catCold, name: 'Ayran', price: 25, station: 'bar', prepTime: 2, recipe: 'Yoğurt + su + tuz. Köpürt.' },
    // Food (kitchen)
    { cat: catFood, name: 'Tost', price: 80, station: 'kitchen', prepTime: 10, recipe: '2 dilim ekmek arası kaşar, sucuk, domates. Tost makinesinde 3 dk.' },
    { cat: catFood, name: 'Hamburger', price: 180, station: 'kitchen', prepTime: 15, recipe: 'Köfte ızgara, hamburger ekmeği, marul, domates, soğan, sos.' },
    { cat: catFood, name: 'Pasta', price: 120, station: 'kitchen', prepTime: 12, recipe: 'Spaghetti domates sosu ile. Üzerine parmesan serp.' },
    { cat: catFood, name: 'Çorba', price: 65, station: 'kitchen', prepTime: 8, recipe: 'Mercimek çorbası — limon ile servis et.' },
    // Dessert
    { cat: catDessert, name: 'Cheesecake', price: 95, station: 'dessert', prepTime: 3, recipe: 'Hazır dilim — buz gibi servis et.' },
    { cat: catDessert, name: 'Tiramisu', price: 110, station: 'dessert', prepTime: 3, recipe: 'Hazır dilim — kakao tozu ile süsle.' },
    { cat: catDessert, name: 'Sufle', price: 130, station: 'dessert', prepTime: 12, recipe: '180°C fırında 10 dk. Dış kabuk, iç akışkan. Vanilya dondurması ile.' },
  ]
  for (const it of menuItems) {
    await db.menuItem.create({
      data: {
        categoryId: it.cat.id,
        name: it.name,
        price: it.price,
        currency: 'TRY',
        prepTime: it.prepTime,
        station: it.station,
        recipe: it.recipe,
        sortOrder: 0,
        isAvailable: true,
      },
    })
  }

  // Demo sipariş — M1 masasına (bar + mutfak + tatlı kapsamlı)
  const order1 = await db.cafeOrder.create({
    data: {
      cafeId: cafe1.id,
      tableId: (await db.cafeTable.findFirst({ where: { cafeId: cafe1.id, number: 'M1' } }))?.id ?? null,
      number: 'S-0001',
      status: 'hazirlaniyor',
      type: 'dine_in',
      subtotal: 360, taxTotal: 0, total: 360,
      createdById: t1Komi.id,
    },
  })
  const itemsForOrder1 = [
    { name: 'Cappuccino', unitPrice: 60, qty: 2, station: 'bar', status: 'hazir' },
    { name: 'Ice Latte', unitPrice: 75, qty: 1, station: 'bar', status: 'hazirlaniyor' },
    { name: 'Tost', unitPrice: 80, qty: 1, station: 'kitchen', status: 'bekliyor' },
    { name: 'Cheesecake', unitPrice: 85, qty: 1, station: 'dessert', status: 'bekliyor' },
  ]
  for (const it of itemsForOrder1) {
    const mi = await db.menuItem.findFirst({ where: { name: it.name } })
    await db.cafeOrderItem.create({
      data: {
        orderId: order1.id,
        menuItemId: mi?.id ?? null,
        name: it.name,
        qty: it.qty,
        unitPrice: it.unitPrice,
        status: it.status,
        station: it.station,
      },
    })
  }

  // Ödenmiş bir sipariş (bugün) — M2 masasına (kasa raporu için)
  const order2 = await db.cafeOrder.create({
    data: {
      cafeId: cafe1.id,
      tableId: (await db.cafeTable.findFirst({ where: { cafeId: cafe1.id, number: 'M2' } }))?.id ?? null,
      number: 'S-0002',
      status: 'odendi',
      type: 'dine_in',
      subtotal: 245, taxTotal: 0, total: 245,
      createdById: t1Komi.id,
      createdAt: new Date(Date.now() - 3600 * 1000 * 2),
    },
  })
  const itemsForOrder2 = [
    { name: 'Türk Kahvesi', unitPrice: 50, qty: 2, station: 'bar', status: 'servis_edildi' },
    { name: 'Çorba', unitPrice: 65, qty: 1, station: 'kitchen', status: 'servis_edildi' },
    { name: 'Sufle', unitPrice: 130, qty: 1, station: 'dessert', status: 'servis_edildi' },
  ]
  for (const it of itemsForOrder2) {
    const mi = await db.menuItem.findFirst({ where: { name: it.name } })
    await db.cafeOrderItem.create({
      data: {
        orderId: order2.id,
        menuItemId: mi?.id ?? null,
        name: it.name,
        qty: it.qty,
        unitPrice: it.unitPrice,
        status: it.status,
        station: it.station,
      },
    })
  }
  await db.cafePayment.create({
    data: {
      orderId: order2.id,
      amount: 150,
      method: 'cash',
      status: 'tamamlandi',
    },
  })
  await db.cafePayment.create({
    data: {
      orderId: order2.id,
      amount: 95,
      method: 'card',
      status: 'tamamlandi',
    },
  })

  const counts = {
    tenants: 2,
    users: 11,
    customers: 30,
    contacts: 50,
    activities: 100,
    deals: 25,
    tasks: 20,
    notes: 30,
    leads: 15,
    mapsSearches: 3,
    auditLogs: 10,
    products: 4,
    cafes: 2,
    cafeTables: 13,
    menuItems: menuItems.length,
  }

  return { success: true, message: 'Demo veri başarıyla oluşturuldu', counts }
}
