// Session yönetimi — demo auth (localStorage tabanlı)
// Gerçek production'da NextAuth/Supabase Auth ile değiştirilebilir.

import { cookies } from 'next/headers'
import { db } from './db'
import { getRolePermissions } from './rbac'
import type { SessionUser } from '@/types'

const SESSION_COOKIE = 'gnc_session'
const SESSION_HEADER = 'x-gnc-session'

// Server-side: request'ten session al
export async function getServerSession(): Promise<SessionUser | null> {
  try {
    const cookieStore = await cookies()
    const sessionToken = cookieStore.get(SESSION_COOKIE)?.value
    if (!sessionToken) return null
    return await resolveSession(sessionToken)
  } catch {
    return null
  }
}

// Header'dan session al (client API çağrıları için)
export async function getServerSessionFromRequest(req: Request): Promise<SessionUser | null> {
  try {
    const sessionToken =
      req.headers.get(SESSION_HEADER) ||
      new URL(req.url).searchParams.get('session') ||
      req.headers.get('cookie')?.match(new RegExp(`${SESSION_COOKIE}=([^;]+)`))?.[1]
    if (!sessionToken) return null
    return await resolveSession(sessionToken)
  } catch {
    return null
  }
}

async function resolveSession(token: string): Promise<SessionUser | null> {
  const user = await db.user.findUnique({
    where: { id: token },
    include: { tenant: true },
  })
  if (!user || user.status !== 'active') return null
  const permissions = JSON.parse(user.permissions || '[]') as string[]
  // Rolün varsayılan yetkileri yoksa ekle (minimum garanti)
  const rolePerms = getRolePermissions(user.role as SessionUser['role'])
  const allPerms = Array.from(new Set([...permissions, ...rolePerms])) as SessionUser['permissions']
  return {
    id: user.id,
    tenantId: user.tenantId,
    email: user.email,
    name: user.name,
    role: user.role as SessionUser['role'],
    permissions: allPerms,
    managerId: user.managerId,
    title: user.title,
    phone: user.phone,
    avatarUrl: user.avatarUrl,
    tenant: {
      id: user.tenant.id,
      name: user.tenant.name,
      plan: user.tenant.plan,
      defaultCurrency: user.tenant.defaultCurrency,
      country: user.tenant.country,
    },
  }
}

// Session oluştur (login)
export async function createSession(userId: string): Promise<string> {
  return userId // demo: token = userId
}

// Audit log yazma yardımcısı
export async function writeAuditLog(params: {
  tenantId: string
  actorId: string | null
  action: string
  entity: string
  entityId?: string | null
  before?: unknown
  after?: unknown
}) {
  try {
    await db.auditLog.create({
      data: {
        tenantId: params.tenantId,
        actorId: params.actorId,
        action: params.action,
        entity: params.entity,
        entityId: params.entityId ?? null,
        before: params.before ? JSON.stringify(params.before) : null,
        after: params.after ? JSON.stringify(params.after) : null,
      },
    })
  } catch (e) {
    console.error('Audit log yazılamadı:', e)
  }
}
