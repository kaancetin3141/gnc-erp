import type { PermissionKey, Role, SessionUser } from '@/types'

// Rol → varsayılan yetki seti
export const ROLE_PERMISSIONS: Record<Role, PermissionKey[]> = {
  superadmin: [
    'customers.view.own', 'customers.view.team', 'customers.view.all',
    'customers.edit', 'customers.delete',
    'leads.import', 'leads.view', 'leads.edit',
    'maps.search', 'deals.manage', 'tasks.manage', 'tasks.view',
    'reports.view', 'users.manage', 'roles.manage', 'settings.manage',
    'export.data', 'audit.view', 'erp.manage',
    'production.view', 'production.manage',
    'cafe.view', 'cafe.manage', 'cafe.orders', 'cafe.bar', 'cafe.kitchen',
  ],
  admin: [
    'customers.view.own', 'customers.view.team', 'customers.view.all',
    'customers.edit', 'customers.delete',
    'leads.import', 'leads.view', 'leads.edit',
    'maps.search', 'deals.manage', 'tasks.manage', 'tasks.view',
    'reports.view', 'users.manage', 'roles.manage', 'settings.manage',
    'export.data', 'audit.view', 'erp.manage',
    'production.view', 'production.manage',
    'cafe.view', 'cafe.manage', 'cafe.orders', 'cafe.bar', 'cafe.kitchen',
  ],
  manager: [
    'customers.view.own', 'customers.view.team',
    'customers.edit',
    'leads.import', 'leads.view', 'leads.edit',
    'maps.search', 'deals.manage', 'tasks.manage', 'tasks.view',
    'reports.view', 'export.data',
    'production.view',
    'cafe.view',
  ],
  rep: [
    'customers.view.own', 'customers.edit',
    'leads.import', 'leads.view', 'leads.edit',
    'maps.search', 'deals.manage', 'tasks.view',
    // PRIVACY-TEMPLATES (#3): rep kendi performans raporunu görebilir (sadece kendi verisi)
    'reports.view',
    'production.view',
  ],
  readonly: [
    'customers.view.own', 'leads.view', 'tasks.view',
  ],
  stock: [
    'production.view', 'production.manage',
  ],
  // Kafe ERP rolleri — kasa (kasiyer), barmen (barista), komi (garson)
  kasa: [
    'cafe.view', 'cafe.manage', 'cafe.orders', 'cafe.kitchen',
  ],
  barmen: [
    'cafe.view', 'cafe.bar',
  ],
  komi: [
    'cafe.view', 'cafe.orders', 'cafe.kitchen',
  ],
}

export const ROLE_LABELS: Record<Role, string> = {
  superadmin: 'Süper Admin',
  admin: 'Şirket Admini',
  manager: 'Müdür',
  rep: 'Satış Temsilcisi',
  readonly: 'Salt Okunur',
  stock: 'Stok Sorumlusu',
  kasa: 'Kasa',
  barmen: 'Barmen',
  komi: 'Komi',
}

export const ALL_PERMISSIONS: { key: PermissionKey; label: string; group: string }[] = [
  { key: 'customers.view.own', label: 'Kendi müşterilerini görüntüle', group: 'Müşteriler' },
  { key: 'customers.view.team', label: 'Ekip müşterilerini görüntüle', group: 'Müşteriler' },
  { key: 'customers.view.all', label: 'Tüm müşterileri görüntüle', group: 'Müşteriler' },
  { key: 'customers.edit', label: 'Müşteri düzenle', group: 'Müşteriler' },
  { key: 'customers.delete', label: 'Müşteri sil', group: 'Müşteriler' },
  { key: 'leads.import', label: 'Lead içe aktar', group: 'Potansiyel Müşteri' },
  { key: 'leads.view', label: 'Leadleri görüntüle', group: 'Potansiyel Müşteri' },
  { key: 'leads.edit', label: 'Lead düzenle', group: 'Potansiyel Müşteri' },
  { key: 'maps.search', label: 'Harita araması yap', group: 'Potansiyel Müşteri' },
  { key: 'deals.manage', label: 'Fırsat yönet', group: 'Satış' },
  { key: 'tasks.manage', label: 'Görev yönet', group: 'Satış' },
  { key: 'tasks.view', label: 'Görevleri görüntüle', group: 'Satış' },
  { key: 'reports.view', label: 'Raporları görüntüle', group: 'Raporlar' },
  { key: 'export.data', label: 'Veri dışa aktar', group: 'Raporlar' },
  { key: 'users.manage', label: 'Kullanıcı yönet', group: 'Yönetim' },
  { key: 'roles.manage', label: 'Rol/yetki yönet', group: 'Yönetim' },
  { key: 'settings.manage', label: 'Ayarları yönet', group: 'Yönetim' },
  { key: 'audit.view', label: 'Denetim kayıtlarını gör', group: 'Yönetim' },
  { key: 'erp.manage', label: 'ERP modülünü yönet', group: 'ERP' },
  { key: 'production.view', label: 'Üretim listesini görüntüle', group: 'Üretim' },
  { key: 'production.manage', label: 'Üretim kalemlerini yönet', group: 'Üretim' },
  { key: 'cafe.view', label: 'Kafe modülünü görüntüle', group: 'Kafe' },
  { key: 'cafe.manage', label: 'Kafe yönetimi (masa/menü/sipariş)', group: 'Kafe' },
  { key: 'cafe.orders', label: 'Sipariş alma (komi/kasa)', group: 'Kafe' },
  { key: 'cafe.bar', label: 'Bar istasyonu (barmen)', group: 'Kafe' },
  { key: 'cafe.kitchen', label: 'Mutfak istasyonu (komi/admin)', group: 'Kafe' },
]

export function getRolePermissions(role: Role): PermissionKey[] {
  return ROLE_PERMISSIONS[role] ?? []
}

export function hasPermission(user: SessionUser | null, key: PermissionKey): boolean {
  if (!user) return false
  return user.permissions.includes(key)
}

export function hasAnyPermission(user: SessionUser | null, keys: PermissionKey[]): boolean {
  if (!user) return false
  return keys.some((k) => user.permissions.includes(k))
}

// Görünürlük kapsamı: own | team | all | none
export function getViewScope(user: SessionUser | null): 'all' | 'team' | 'own' | 'none' {
  if (!user) return 'none'
  if (user.permissions.includes('customers.view.all')) return 'all'
  if (user.permissions.includes('customers.view.team')) return 'team'
  if (user.permissions.includes('customers.view.own')) return 'own'
  return 'none'
}

// Bir kullanıcının görebileceği kullanıcı ID'lerini hesapla (ast hiyerarşisi)
export function getVisibleUserIds(users: { id: string; managerId: string | null }[], currentUserId: string): string[] {
  const result = new Set<string>([currentUserId])
  let changed = true
  while (changed) {
    changed = false
    for (const u of users) {
      if (u.managerId && result.has(u.managerId) && !result.has(u.id)) {
        result.add(u.id)
        changed = true
      }
    }
  }
  return Array.from(result)
}

// Yetki devri kontrolü: actor, target kullanıcıya yetki verebilir mi?
export function canDelegatePermission(
  actor: SessionUser,
  targetUserId: string,
  permission: PermissionKey,
  subordinates: string[],
): boolean {
  // Kendi yetkisinde olmalı
  if (!actor.permissions.includes(permission)) return false
  // Hedef kendi astı olmalı (veya kendisi)
  if (targetUserId === actor.id) return false // kendine atayamaz (zaten var)
  if (!subordinates.includes(targetUserId)) return false
  return true
}
