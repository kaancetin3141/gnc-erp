'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { apiGet } from '@/lib/api-client'
import { useAppStore } from '@/store/app-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import {
  Users, DollarSign, TrendingUp, CheckSquare, AlertTriangle,
  Phone, Mail, MessageCircle, MapPin, StickyNote, Calendar,
  ArrowUpRight, ArrowRight, Building2, Clock, ShieldAlert,
} from 'lucide-react'
import { formatCurrency, formatRelative, formatDate, initials, daysSince, getActivityStatusColor } from '@/lib/format'
import { DEAL_STAGES, getLabel } from '@/lib/constants'
import { cn } from '@/lib/utils'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
  AreaChart, Area, CartesianGrid,
} from 'recharts'
import { useCountUp } from '@/hooks/use-count-up'
import { WidgetsSection } from './widgets/widgets-section'

interface DashboardData {
  restricted?: boolean
  message?: string
  range: string
  customers: { total: number; newThisMonth: number; staleCount: number }
  deals: { activeCount: number; totalPipelineValue: number; wonThisMonth: number; revenueThisMonth: number }
  tasks: { openCount: number; overdueCount: number; upcomingCount: number }
  pipelineByStage: { stage: string; count: number; totalValue: number }[]
  activitiesOverTime: { date: string; count: number }[]
  recentActivities: {
    id: string; type: string; subject: string; detail: string | null
    date: string; outcome: string | null
    user: { id: string; name: string } | null
    customer: { id: string; name: string } | null
  }[]
  upcomingTasks: {
    id: string; title: string; dueDate: string; priority: string
    assignee: { id: string; name: string } | null
    customer: { id: string; name: string } | null
  }[]
}

const ACTIVITY_ICONS: Record<string, typeof Phone> = {
  arama: Phone, toplanti: Users, email: Mail, whatsapp: MessageCircle,
  not: StickyNote, ziyaret: MapPin, gorev: CheckSquare,
}
const ACTIVITY_COLORS: Record<string, string> = {
  arama: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30',
  toplanti: 'text-violet-600 bg-violet-50 dark:bg-violet-950/30',
  email: 'text-sky-600 bg-sky-50 dark:bg-sky-950/30',
  whatsapp: 'text-green-600 bg-green-50 dark:bg-green-950/30',
  not: 'text-amber-600 bg-amber-50 dark:bg-amber-950/30',
  ziyaret: 'text-rose-600 bg-rose-50 dark:bg-rose-950/30',
  gorev: 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/30',
}

export function DashboardView() {
  const { user, setView, openCustomer } = useAppStore()
  const [range, setRange] = useState<'today' | '7d' | '30d' | 'month' | 'quarter' | 'all'>('month')
  const { data, isLoading } = useQuery({
    queryKey: ['dashboard', range],
    queryFn: () => apiGet<DashboardData>(`/api/dashboard?range=${range}`),
    refetchInterval: 60_000,
  })

  // PRIVACY-TEMPLATES (#3): depo rolü için dashboard kısıtlı
  if (user?.role === 'stock' || data?.restricted) {
    return (
      <div className="flex items-center justify-center min-h-[60vh] p-6">
        <Card className="p-8 max-w-md text-center">
          <div className="w-14 h-14 rounded-full bg-amber-50 dark:bg-amber-950/30 flex items-center justify-center mx-auto mb-4">
            <ShieldAlert className="w-7 h-7 text-amber-500" />
          </div>
          <h3 className="font-semibold text-lg mb-2">Depo rolü için erişim kısıtlıdır</h3>
          <p className="text-sm text-muted-foreground">
            Satış ve müşteri verileri gizlilik gereği yalnızca yönetici/admin rolleri tarafından görüntülenebilir.
            Depo rolü olarak üretim listesine erişebilirsiniz.
          </p>
        </Card>
      </div>
    )
  }

  if (isLoading || !data) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-28" />)}
        </div>
        <div className="grid lg:grid-cols-3 gap-4">
          <Skeleton className="h-80 lg:col-span-2" />
          <Skeleton className="h-80" />
        </div>
      </div>
    )
  }

  const kpis = [
    {
      label: 'Toplam Müşteri',
      value: data.customers.total,
      numericValue: data.customers.total,
      sub: `Bu ay +${data.customers.newThisMonth} yeni`,
      icon: Users,
      color: 'from-sky-500 to-blue-600',
      onClick: () => setView('customers'),
    },
    {
      label: 'Aktif Pipeline',
      value: formatCurrency(data.deals.totalPipelineValue),
      numericValue: data.deals.totalPipelineValue,
      sub: `${data.deals.activeCount} açık fırsat`,
      icon: TrendingUp,
      color: 'from-violet-500 to-purple-600',
      onClick: () => setView('pipeline'),
    },
    {
      label: 'Bu Ay Ciro',
      value: formatCurrency(data.deals.revenueThisMonth),
      numericValue: data.deals.revenueThisMonth,
      sub: `${data.deals.wonThisMonth} kazanıldı`,
      icon: DollarSign,
      color: 'from-emerald-500 to-teal-600',
      onClick: () => setView('pipeline'),
    },
    {
      label: 'Açık Görevler',
      value: data.tasks.openCount,
      numericValue: data.tasks.openCount,
      sub: data.tasks.overdueCount > 0 ? `${data.tasks.overdueCount} gecikmiş!` : 'Zamanında',
      icon: CheckSquare,
      color: data.tasks.overdueCount > 0 ? 'from-red-500 to-rose-600' : 'from-amber-500 to-orange-600',
      onClick: () => setView('tasks'),
    },
  ]

  const chartData = DEAL_STAGES
    .filter((s) => s.value !== 'kazanıldı' && s.value !== 'kaybedildi')
    .map((s) => {
      const found = data.pipelineByStage.find((p) => p.stage === s.value)
      return { stage: s.label, count: found?.count ?? 0, value: found?.totalValue ?? 0 }
    })

  const maxCount = Math.max(...chartData.map((d) => d.count), 1)

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Hoş geldin banner */}
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-900 text-white p-6 lg:p-7">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 30%, white 1px, transparent 1px)',
          backgroundSize: '40px 40px, 60px 60px',
        }} />
        <div className="relative z-10 flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="text-xs text-slate-300 mb-1">
              {new Date().toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </div>
            <h2 className="text-2xl lg:text-3xl font-bold tracking-tight">
              Merhaba, {user?.name.split(' ')[0]} 👋
            </h2>
            <p className="text-sm text-slate-300 mt-1">
              {data.customers.staleCount > 0 ? (
                <span className="text-amber-300">
                  {data.customers.staleCount} müşteri iletişimsiz — ilgilenmen gerek.
                </span>
              ) : (
                <span className="text-emerald-300">Tüm müşterilerle iletişim güncel!</span>
              )}
            </p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" size="sm" onClick={() => setView('customers')} className="bg-white/10 border-white/20 text-white hover:bg-white/20 hover:text-white">
              <Users className="w-4 h-4 mr-1.5" /> Müşteriler
            </Button>
            <Button size="sm" onClick={() => setView('leads-maps')} className="bg-emerald-500 hover:bg-emerald-600 text-white border-0">
              <MapPin className="w-4 h-4 mr-1.5" /> Yeni Lead Bul
            </Button>
          </div>
        </div>
        {/* Mini quick stats */}
        <div className="relative z-10 grid grid-cols-2 lg:grid-cols-4 gap-3 mt-5 pt-5 border-t border-white/10">
          <div>
            <div className="text-xs text-slate-400">Müşteri</div>
            <div className="text-lg font-bold tabular-nums">{data.customers.total}</div>
          </div>
          <div>
            <div className="text-xs text-slate-400">Açık Fırsat</div>
            <div className="text-lg font-bold tabular-nums">{data.deals.activeCount}</div>
          </div>
          <div>
            <div className="text-xs text-slate-400">Açık Görev</div>
            <div className="text-lg font-bold tabular-nums">{data.tasks.openCount}</div>
          </div>
          <div>
            <div className="text-xs text-slate-400">Bu Ay Ciro</div>
            <div className="text-lg font-bold tabular-nums text-emerald-300">{formatCurrency(data.deals.revenueThisMonth)}</div>
          </div>
        </div>
      </div>

      {/* Date range selector */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs text-muted-foreground">Dönem:</span>
        <div className="inline-flex rounded-lg border border-border bg-muted/30 p-0.5 gap-0.5">
          {([
            { value: 'today', label: 'Bugün' },
            { value: '7d', label: '7G' },
            { value: '30d', label: '30G' },
            { value: 'month', label: 'Bu Ay' },
            { value: 'quarter', label: 'Çeyrek' },
            { value: 'all', label: 'Tümü' },
          ] as const).map((opt) => (
            <button
              key={opt.value}
              onClick={() => setRange(opt.value)}
              className={cn(
                'px-2.5 py-1 text-xs font-medium rounded-md transition-colors',
                range === opt.value
                  ? 'bg-background text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI kartları */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <KpiCard key={kpi.label} kpi={kpi} />
        ))}
      </div>

      {/* Widget'lar — hava durumu, mesajlar, döviz, haberler, streak */}
      <WidgetsSection />

      {/* İkincil satır */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Pipeline grafiği */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Satış Hunisi</CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setView('pipeline')} className="text-xs h-7">
                Tümü <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {chartData.every((d) => d.count === 0) ? (
              <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">
                Açık fırsat yok.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <XAxis
                    dataKey="stage"
                    tick={{ fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} width={30} />
                  <Tooltip
                    contentStyle={{
                      borderRadius: '8px',
                      border: '1px solid hsl(var(--border))',
                      fontSize: '12px',
                    }}
                    formatter={(value: number, name: string) =>
                      name === 'value' ? [formatCurrency(value), 'Değer'] : [value, 'Fırsat']
                    }
                  />
                  <Bar dataKey="count" radius={[6, 6, 0, 0]} maxBarSize={60}>
                    {chartData.map((_, i) => (
                      <Cell key={i} fill={['#94a3b8', '#0ea5e9', '#f59e0b', '#8b5cf6'][i % 4]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Yaklaşan görevler */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Yaklaşan Görevler</CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setView('tasks')} className="text-xs h-7">
                Tümü <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-2 max-h-[280px] overflow-y-auto custom-scroll">
            {data.upcomingTasks.length === 0 ? (
              <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">
                <div className="text-center">
                  <CheckSquare className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  Önümüzdeki 7 günde görev yok.
                </div>
              </div>
            ) : (
              data.upcomingTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                  onClick={() => task.customer && openCustomer(task.customer.id)}
                >
                  <div className={cn(
                    'w-2 h-2 rounded-full mt-1.5 shrink-0',
                    task.priority === 'acil' ? 'bg-red-500' :
                    task.priority === 'yuksek' ? 'bg-amber-500' :
                    task.priority === 'orta' ? 'bg-sky-500' : 'bg-gray-400'
                  )} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{task.title}</div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                      <Clock className="w-3 h-3" />
                      <span>{formatDate(task.dueDate)}</span>
                      {task.customer && (
                        <>
                          <span>·</span>
                          <span className="truncate">{task.customer.name}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Aktivite trend grafiği */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base">Aktivite Trendi</CardTitle>
              <p className="text-xs text-muted-foreground mt-0.5">Son 30 gün · Toplam {data.activitiesOverTime.reduce((s, d) => s + d.count, 0)} aktivite</p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <div className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>Günlük aktivite</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {data.activitiesOverTime.every((d) => d.count === 0) ? (
            <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">
              Son 30 günde aktivite kaydı yok
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={data.activitiesOverTime} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="activityGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.3} vertical={false} />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v: string) => {
                    const d = new Date(v)
                    return `${d.getDate()}.${d.getMonth() + 1}`
                  }}
                  interval={4}
                />
                <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} width={25} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    borderRadius: '8px',
                    border: '1px solid hsl(var(--border))',
                    fontSize: '12px',
                  }}
                  labelFormatter={(v: string) => {
                    const d = new Date(v)
                    return `${d.getDate()}.${d.getMonth() + 1}.${d.getFullYear()}`
                  }}
                  formatter={(value: number) => [`${value} aktivite`, '']}
                />
                <Area
                  type="monotone"
                  dataKey="count"
                  stroke="#10b981"
                  strokeWidth={2}
                  fill="url(#activityGradient)"
                  dot={false}
                  activeDot={{ r: 4, fill: '#10b981' }}
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* Son aktiviteler + İletişimsiz müşteriler */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Son aktiviteler */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Son Aktiviteler</CardTitle>
          </CardHeader>
          <CardContent>
            {data.recentActivities.length === 0 ? (
              <div className="h-40 flex items-center justify-center text-sm text-muted-foreground">
                Henüz aktivite kaydedilmedi.
              </div>
            ) : (
              <div className="space-y-1">
                {data.recentActivities.slice(0, 8).map((act) => {
                  const Icon = ACTIVITY_ICONS[act.type] ?? Phone
                  return (
                    <div
                      key={act.id}
                      className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                      onClick={() => act.customer && openCustomer(act.customer.id)}
                    >
                      <div className={cn(
                        'w-8 h-8 rounded-lg flex items-center justify-center shrink-0',
                        ACTIVITY_COLORS[act.type] ?? 'text-gray-600 bg-gray-50',
                      )}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium truncate">{act.subject}</span>
                          {act.outcome && (
                            <Badge variant="outline" className={cn(
                              'text-[10px] px-1.5 py-0 h-4',
                              act.outcome === 'basarili' ? 'text-emerald-600 border-emerald-200' :
                              act.outcome === 'basarisiz' ? 'text-red-600 border-red-200' :
                              'text-amber-600 border-amber-200'
                            )}>
                              {act.outcome}
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                          {act.customer && <span className="truncate">{act.customer.name}</span>}
                          <span>·</span>
                          <span>{act.user?.name ?? 'Bilinmiyor'}</span>
                          <span>·</span>
                          <span>{formatRelative(act.date)}</span>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* İletişimsiz müşteriler uyarısı */}
        <Card className="border-amber-200 dark:border-amber-900/50">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/30 flex items-center justify-center">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
              </div>
              <CardTitle className="text-base">Dikkat Gerekli</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="p-3 rounded-lg bg-amber-50/50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/30">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">İletişimsiz Müşteriler</span>
                <span className="text-lg font-bold text-amber-600">{data.customers.staleCount}</span>
              </div>
              <p className="text-xs text-muted-foreground">30+ gündür iletişim kurulmamış</p>
              <Progress value={data.customers.total > 0 ? (data.customers.staleCount / data.customers.total) * 100 : 0} className="h-1.5 mt-2" />
            </div>

            <div className="p-3 rounded-lg bg-red-50/50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/30">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">Gecikmiş Görevler</span>
                <span className="text-lg font-bold text-red-600">{data.tasks.overdueCount}</span>
              </div>
              <p className="text-xs text-muted-foreground">Acilen tamamlanmalı</p>
            </div>

            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={() => setView('customers')}
            >
              <Users className="w-4 h-4 mr-1.5" />
              Müşterileri Gör
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// KPI Card with count-up animation
interface KpiData {
  label: string
  value: string | number
  numericValue: number
  sub: string
  icon: typeof Users
  color: string
  onClick: () => void
}

function KpiCard({ kpi }: { kpi: KpiData }) {
  const animated = useCountUp(kpi.numericValue, 900)
  const displayValue = typeof kpi.value === 'string' && kpi.value.includes('₺')
    ? formatCurrency(animated, 'TRY')
    : typeof kpi.value === 'number'
      ? animated
      : kpi.value

  return (
    <Card
      className="relative overflow-hidden cursor-pointer hover:shadow-md transition-all duration-300 group hover:-translate-y-0.5"
      onClick={kpi.onClick}
    >
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div className={cn('w-10 h-10 rounded-lg bg-gradient-to-br flex items-center justify-center shadow-sm', kpi.color)}>
            <kpi.icon className="w-5 h-5 text-white" />
          </div>
          <ArrowUpRight className="w-4 h-4 text-muted-foreground/40 group-hover:text-foreground transition-colors" />
        </div>
        <div className="text-2xl font-bold tracking-tight animate-count-up">{displayValue}</div>
        <div className="text-sm text-muted-foreground mt-0.5">{kpi.label}</div>
        <div className="text-xs text-muted-foreground/80 mt-1.5">{kpi.sub}</div>
      </CardContent>
    </Card>
  )
}
