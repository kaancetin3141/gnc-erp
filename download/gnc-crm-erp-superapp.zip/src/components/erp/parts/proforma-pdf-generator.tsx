'use client'

import { useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { apiGet } from '@/lib/api-client'

import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Printer, FileText } from 'lucide-react'
import { formatCurrency, formatDate } from '@/lib/format'
import { useAppStore } from '@/store/app-store'
import { cn } from '@/lib/utils'
import type { Quote } from './types'
import { getProformaStatusMeta } from './proforma-utils'

// ============================================================
// Proforma PDF/Print Generator
// İstemci tarafında profesyonel bir proforma fatura dokümanı
// render eder. Kullanıcı window.print() ile PDF olarak
// kaydedebilir veya yazdırabilir.
// ============================================================

interface Props {
  proformaId: string | null
  open: boolean
  onOpenChange: (v: boolean) => void
}

export function ProformaPdfGenerator({ proformaId, open, onOpenChange }: Props) {
  const { user } = useAppStore()

  const { data: proforma, isLoading } = useQuery({
    queryKey: ['proforma-print', proformaId],
    queryFn: () => apiGet<Quote>(`/api/proforma/${proformaId}`),
    enabled: !!proformaId && open,
  })

  const companyName = user?.tenant.name ?? 'Şirket'
  const lines = proforma?.lines ?? []
  const statusMeta = proforma ? getProformaStatusMeta(proforma.status) : null

  const totalText = useMemo(() => {
    if (!proforma) return ''
    const symbol = proforma.currency === 'TRY' ? '₺' : proforma.currency === 'USD' ? '$' : proforma.currency === 'EUR' ? '€' : proforma.currency
    const num = new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(proforma.total)
    return `${num} ${symbol}`
  }, [proforma])

  if (!proformaId) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[92vh] overflow-y-auto custom-scroll print:max-w-none print:max-h-none print:p-0 print:shadow-none print:overflow-visible">
        <DialogHeader className="print:hidden">
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-600" />
                Proforma Önizleme
              </DialogTitle>
              <DialogDescription className="mt-1">
                Profesyonel proforma fatura dokümanı. &quot;Yazdır&quot; butonu ile PDF olarak kaydedebilirsiniz.
              </DialogDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => window.print()}>
              <Printer className="w-4 h-4 mr-1.5" /> Yazdır / PDF
            </Button>
          </div>
        </DialogHeader>

        {isLoading || !proforma ? (
          <div className="space-y-3 py-6">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        ) : (
          <div className="overflow-y-auto max-h-[70vh] print:overflow-visible print:max-h-none">
            <div className="p-8 bg-white text-black print:p-0 print-content">
              {/* Header */}
              <div className="flex items-start justify-between mb-6 pb-4 border-b-2 border-gray-200">
                <div>
                  <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center font-bold text-white text-xl mb-3">
                    G
                  </div>
                  <div className="font-bold text-xl">{companyName}</div>
                  <div className="text-xs text-gray-500 mt-0.5">GNC CRM</div>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-emerald-700 tracking-tight">PROFORMA FATURA</div>
                  <div className="text-sm font-mono mt-1.5 text-gray-700">{proforma.number}</div>
                  <div className="text-xs text-gray-500 mt-1">Tarih: {formatDate(proforma.issueDate)}</div>
                  {proforma.validUntil && (
                    <div className="text-xs text-gray-500">Geçerlilik: {formatDate(proforma.validUntil)}</div>
                  )}
                </div>
              </div>

              {/* Customer info */}
              <div className="mb-6 grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Sayın</div>
                  <div className="text-base font-semibold">{proforma.customer?.name ?? '—'}</div>
                  {proforma.customer?.address && (
                    <div className="text-xs text-gray-600 mt-0.5">{proforma.customer.address}</div>
                  )}
                  {proforma.customer?.city && (
                    <div className="text-xs text-gray-600">{proforma.customer.city}</div>
                  )}
                  {proforma.customer?.phone && (
                    <div className="text-xs text-gray-600 mt-0.5">Tel: {proforma.customer.phone}</div>
                  )}
                  {proforma.customer?.email && (
                    <div className="text-xs text-gray-600">E-posta: {proforma.customer.email}</div>
                  )}
                  {proforma.customer?.taxNumber && (
                    <div className="text-xs text-gray-600">VKN: {proforma.customer.taxNumber}</div>
                  )}
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Durum</div>
                  {statusMeta && (
                    <Badge variant="outline" className={cn('text-xs', statusMeta.color)}>
                      {statusMeta.label}
                    </Badge>
                  )}
                  <div className="text-[10px] uppercase tracking-wider text-gray-500 mt-3 mb-1">Para Birimi</div>
                  <div className="text-sm font-medium">{proforma.currency}</div>
                </div>
              </div>

              {/* Line items table */}
              {lines.length > 0 ? (
                <table className="w-full text-sm mb-6 border border-gray-200">
                  <thead>
                    <tr className="bg-gray-50 border-b-2 border-gray-300">
                      <th className="text-left py-2.5 px-3 text-xs uppercase tracking-wider text-gray-600">#</th>
                      <th className="text-left py-2.5 px-3 text-xs uppercase tracking-wider text-gray-600">Kalem</th>
                      <th className="text-right py-2.5 px-3 text-xs uppercase tracking-wider text-gray-600 w-20">Miktar</th>
                      <th className="text-right py-2.5 px-3 text-xs uppercase tracking-wider text-gray-600 w-28">Birim Fiyat</th>
                      <th className="text-right py-2.5 px-3 text-xs uppercase tracking-wider text-gray-600 w-14">KDV</th>
                      <th className="text-right py-2.5 px-3 text-xs uppercase tracking-wider text-gray-600 w-28">Tutar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {lines.map((line, i) => (
                      <tr key={line.id ?? i} className="border-b border-gray-100">
                        <td className="py-2 px-3 text-gray-500 tabular-nums">{i + 1}</td>
                        <td className="py-2 px-3">
                          <div className="font-medium">{line.description}</div>
                          {line.product && (
                            <div className="text-[10px] text-gray-500">
                              {line.product.name}
                              {line.product.sku ? ` · ${line.product.sku}` : ''}
                            </div>
                          )}
                        </td>
                        <td className="text-right py-2 px-3 tabular-nums">{line.qty}</td>
                        <td className="text-right py-2 px-3 tabular-nums">{formatCurrency(line.unitPrice, proforma.currency)}</td>
                        <td className="text-right py-2 px-3 tabular-nums text-gray-600">%{line.taxRate}</td>
                        <td className="text-right py-2 px-3 tabular-nums font-medium">{formatCurrency(line.lineTotal, proforma.currency)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="mb-6 p-4 bg-gray-50 rounded text-sm text-gray-500 text-center border border-gray-200">
                  Bu proforma için kalem bilgisi bulunamadı.
                </div>
              )}

              {/* Totals */}
              <div className="flex justify-end mb-8">
                <div className="w-full max-w-xs space-y-1.5">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Ara Toplam:</span>
                    <span className="tabular-nums">{formatCurrency(proforma.subtotal, proforma.currency)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">KDV:</span>
                    <span className="tabular-nums">{formatCurrency(proforma.taxTotal, proforma.currency)}</span>
                  </div>
                  <div className="flex justify-between text-base font-bold pt-2 border-t-2 border-gray-300">
                    <span>Genel Toplam:</span>
                    <span className="tabular-nums text-emerald-700">{totalText}</span>
                  </div>
                </div>
              </div>

              {/* Validity note + signature area */}
              <div className="grid grid-cols-2 gap-6 pt-4 border-t border-gray-200">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Geçerlilik</div>
                  <div className="text-xs text-gray-700">
                    {proforma.validUntil
                      ? `Bu proforma ${formatDate(proforma.validUntil)} tarihine kadar geçerlidir.`
                      : 'Bu proforma 30 gün geçerlidir.'}
                  </div>
                  <div className="text-xs text-gray-600 mt-2">
                    Fiyatlar KDV dahil değildir; ayrı belirtilmedikçe nakliye hariçtır.
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">İmza &amp; Kaşe</div>
                  <div className="mt-6 ml-auto w-40 h-14 border border-dashed border-gray-300 flex items-center justify-center text-[10px] text-gray-400">
                    {companyName}
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="mt-8 pt-4 border-t text-xs text-gray-400 text-center">
                <p>Bu belge GNC CRM tarafından oluşturulmuştur · {formatDate(new Date())}</p>
                <p className="mt-1">© {new Date().getFullYear()} {companyName}</p>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
