'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { apiGet, apiPatch, apiDelete } from '@/lib/api-client'

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Tooltip, TooltipContent, TooltipTrigger,
} from '@/components/ui/tooltip'
import { toast } from 'sonner'
import {
  Receipt, Pencil, Trash2, RefreshCw, User, Calendar,
  Clock, CheckCircle2, AlertTriangle, TrendingUp, FileText,
  Printer,
} from 'lucide-react'
import { formatCurrency, formatDate } from '@/lib/format'
import { cn } from '@/lib/utils'
import type { Invoice, InvoiceLine } from './types'
import { INVOICE_STATUSES, getInvoiceStatusMeta } from './invoice-utils'

// ============================================================
// Fatura Detay Dialog
// ============================================================

export function InvoiceDetailDialog({
  invoice, open, onOpenChange, onEdit,
}: {
  invoice: Invoice | null
  open: boolean
  onOpenChange: (v: boolean) => void
  onEdit: (inv: Invoice) => void
}) {
  const qc = useQueryClient()
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [changing, setChanging] = useState(false)

  // Detay sorgu
  const { data: detail, isLoading } = useQuery({
    queryKey: ['invoice', invoice?.id],
    queryFn: () => apiGet<Invoice>(`/api/invoices/${invoice!.id}`),
    enabled: !!invoice && open,
  })

  if (!invoice) return null

  const status = getInvoiceStatusMeta(invoice.status)
  const d = detail ?? invoice

  const changeStatus = async (newStatus: string) => {
    setChanging(true)
    try {
      await apiPatch(`/api/invoices/${invoice.id}`, { status: newStatus })
      toast.success('Durum güncellendi')
      qc.invalidateQueries({ queryKey: ['invoice', invoice.id] })
      qc.invalidateQueries({ queryKey: ['invoices'] })
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Güncelleme başarısız')
    } finally {
      setChanging(false)
    }
  }

  const handleDelete = async () => {
    setDeleting(true)
    try {
      await apiDelete(`/api/invoices/${invoice.id}`)
      toast.success('Fatura silindi')
      qc.invalidateQueries({ queryKey: ['invoices'] })
      setDeleteOpen(false)
      onOpenChange(false)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Silme başarısız')
    } finally {
      setDeleting(false)
    }
  }

  // Gecikmiş mi?
  const isOverdue = invoice.status === 'odeme_bekliyor' && invoice.dueDate
    ? new Date(invoice.dueDate).getTime() < Date.now()
    : false

  const lines: InvoiceLine[] = d.lines ?? []

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto custom-scroll print-content">
          <DialogHeader className="print:hidden">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <DialogTitle className="flex items-center gap-2 flex-wrap">
                  <Receipt className="w-5 h-5 text-amber-600 shrink-0" />
                  <span className="font-mono">{invoice.number}</span>
                  <Badge variant="outline" className={cn('text-[10px]', status.color)}>
                    <status.icon className="w-3 h-3 mr-1" />
                    {status.label}
                  </Badge>
                  {isOverdue && (
                    <Badge variant="outline" className="text-[10px] text-red-700 bg-red-50 border-red-200">
                      <AlertTriangle className="w-3 h-3 mr-1" />
                      Vade Geçti
                    </Badge>
                  )}
                </DialogTitle>
                <DialogDescription className="mt-1 flex items-center gap-2 flex-wrap text-xs">
                  <User className="w-3 h-3" />
                  {invoice.customer?.name ?? '—'}
                </DialogDescription>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="sm" onClick={() => window.print()}>
                      <Printer className="w-3.5 h-3.5 mr-1" /> Yazdır
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Faturayı yazdır</TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="sm" onClick={() => onEdit(invoice)}>
                      <Pencil className="w-3.5 h-3.5 mr-1" /> Düzenle
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Faturayı düzenle</TooltipContent>
                </Tooltip>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/30 border-red-200 dark:border-red-900/50"
                  onClick={() => setDeleteOpen(true)}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          </DialogHeader>

          {isLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : (
            <>
              {/* Bilgi kartları */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-1">
                <Card className="bg-muted/30">
                  <CardContent className="p-3">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> Düzenleme
                    </div>
                    <div className="text-sm font-bold mt-0.5">{formatDate(d.issueDate)}</div>
                  </CardContent>
                </Card>
                <Card className="bg-muted/30">
                  <CardContent className="p-3">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" /> Vade
                    </div>
                    <div className="text-sm font-bold mt-0.5">{formatDate(d.dueDate)}</div>
                  </CardContent>
                </Card>
                <Card className="bg-muted/30">
                  <CardContent className="p-3">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Ödeme Tarihi
                    </div>
                    <div className="text-sm font-bold mt-0.5">{formatDate(d.paidDate)}</div>
                  </CardContent>
                </Card>
                <Card className="bg-muted/30">
                  <CardContent className="p-3">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Para Birimi</div>
                    <div className="text-sm font-bold mt-0.5">{d.currency}</div>
                  </CardContent>
                </Card>
              </div>

              {/* Toplamlar */}
              <div className="grid grid-cols-3 gap-3">
                <Card className="bg-muted/20">
                  <CardContent className="p-3">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Ara Toplam</div>
                    <div className="text-base font-bold mt-0.5 tabular-nums">{formatCurrency(d.subtotal, d.currency)}</div>
                  </CardContent>
                </Card>
                <Card className="bg-muted/20">
                  <CardContent className="p-3">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">KDV</div>
                    <div className="text-base font-bold mt-0.5 tabular-nums">{formatCurrency(d.taxTotal, d.currency)}</div>
                  </CardContent>
                </Card>
                <Card className="bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/50">
                  <CardContent className="p-3">
                    <div className="text-[10px] uppercase tracking-wider text-amber-700 dark:text-amber-400">Genel Toplam</div>
                    <div className="text-base font-bold mt-0.5 tabular-nums text-amber-700 dark:text-amber-400">{formatCurrency(d.total, d.currency)}</div>
                  </CardContent>
                </Card>
              </div>

              <Separator />

              {/* Satır detayları (lines) */}
              {lines.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-muted-foreground" />
                    <h4 className="text-sm font-semibold">Kalemler ({lines.length})</h4>
                  </div>
                  <div className="rounded-lg border border-border overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-muted/50">
                          <TableHead className="text-xs uppercase tracking-wider text-muted-foreground py-2">Açıklama</TableHead>
                          <TableHead className="text-xs uppercase tracking-wider text-muted-foreground py-2 text-right">Miktar</TableHead>
                          <TableHead className="text-xs uppercase tracking-wider text-muted-foreground py-2 text-right">Birim</TableHead>
                          <TableHead className="text-xs uppercase tracking-wider text-muted-foreground py-2 text-right">KDV</TableHead>
                          <TableHead className="text-xs uppercase tracking-wider text-muted-foreground py-2 text-right">Tutar</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {lines.map((line) => (
                          <TableRow key={line.id} className="text-sm">
                            <TableCell className="py-2">
                              {line.description}
                              {line.product && (
                                <span className="text-[10px] text-muted-foreground ml-1">({line.product.sku || line.product.name})</span>
                              )}
                            </TableCell>
                            <TableCell className="text-right py-2 tabular-nums">{line.qty}</TableCell>
                            <TableCell className="text-right py-2 tabular-nums">{formatCurrency(line.unitPrice, d.currency)}</TableCell>
                            <TableCell className="text-right py-2 tabular-nums">%{line.taxRate}</TableCell>
                            <TableCell className="text-right py-2 tabular-nums font-medium">{formatCurrency(line.lineTotal, d.currency)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}

              {/* Durum aksiyonları */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-amber-600" />
                  <h4 className="text-sm font-semibold">Durum Yönetimi</h4>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {INVOICE_STATUSES.map((s) => (
                    <Button
                      key={s.value}
                      variant={invoice.status === s.value ? 'default' : 'outline'}
                      size="sm"
                      disabled={changing || invoice.status === s.value}
                      onClick={() => changeStatus(s.value)}
                      className={cn(
                        invoice.status === s.value && 'bg-amber-600 hover:bg-amber-700',
                      )}
                    >
                      <s.icon className="w-3.5 h-3.5 mr-1" />
                      {s.label}
                    </Button>
                  ))}
                </div>

                {invoice.status === 'odendi' && d.paidDate && (
                  <div className="p-2 rounded-md bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    Ödendi — {formatDate(d.paidDate)}
                  </div>
                )}
                {isOverdue && (
                  <div className="p-2 rounded-md bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50 text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" />
                    Vade tarihi geçti. &quot;Gecikti&quot; olarak işaretleyebilirsiniz.
                  </div>
                )}
              </div>

              {/* Çeki Listesi (Packing List) & İrsaliye & Sipariş */}
              <Separator />
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-violet-600" />
                  <h4 className="text-sm font-semibold">Belge Yönetimi</h4>
                </div>

                {/* Sipariş bağlantısı */}
                <div className="p-3 rounded-lg border border-border bg-muted/20">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Sipariş</span>
                    {d.order ? (
                      <Badge variant="outline" className="text-[10px] bg-violet-50 text-violet-700 border-violet-200">
                        {d.order.number}
                      </Badge>
                    ) : (
                      <span className="text-[10px] text-muted-foreground">Siparişe bağlı değil</span>
                    )}
                  </div>
                  {d.order && (
                    <div className="text-xs text-muted-foreground">
                      Sipariş No: <span className="font-mono font-medium text-foreground">{d.order.number}</span>
                      <span className="ml-2">Durum: {d.order.status}</span>
                    </div>
                  )}
                </div>

                {/* Çeki Listesi */}
                <div className="p-3 rounded-lg border border-border bg-muted/20">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Çeki Listesi (Packing List)</span>
                    {d.packingListNo ? (
                      <Badge variant="outline" className="text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200">
                        Düzenlendi
                      </Badge>
                    ) : (
                      <span className="text-[10px] text-muted-foreground">Yok</span>
                    )}
                  </div>
                  {d.packingListNo ? (
                    <div className="text-xs space-y-1">
                      <div>No: <span className="font-mono font-medium">{d.packingListNo}</span></div>
                      {d.packingListDate && <div>Tarih: {formatDate(d.packingListDate)}</div>}
                    </div>
                  ) : (
                    <div className="text-xs text-muted-foreground">Henüz çeki listesi oluşturulmadı.</div>
                  )}
                </div>

                {/* İrsaliye */}
                <div className="p-3 rounded-lg border border-border bg-muted/20">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">İrsaliye (Dispatch Note)</span>
                    {d.dispatchNo ? (
                      <Badge variant="outline" className="text-[10px] bg-sky-50 text-sky-700 border-sky-200">
                        Düzenlendi
                      </Badge>
                    ) : (
                      <span className="text-[10px] text-muted-foreground">Yok</span>
                    )}
                  </div>
                  {d.dispatchNo ? (
                    <div className="text-xs space-y-1">
                      <div>No: <span className="font-mono font-medium">{d.dispatchNo}</span></div>
                      {d.dispatchDate && <div>Tarih: {formatDate(d.dispatchDate)}</div>}
                    </div>
                  ) : (
                    <div className="text-xs text-muted-foreground">Henüz irsaliye düzenlenmedi.</div>
                  )}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Silme onayı */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Faturayı sil?</AlertDialogTitle>
            <AlertDialogDescription>
              <strong>{invoice.number}</strong> numaralı faturayı silmek üzeresiniz.
              Bu işlem geri alınamaz.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>İptal</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault()
                handleDelete()
              }}
              disabled={deleting}
              className="bg-red-600 hover:bg-red-700 focus:ring-red-600"
            >
              {deleting && <RefreshCw className="w-4 h-4 mr-1.5 animate-spin" />}
              Evet, Sil
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
