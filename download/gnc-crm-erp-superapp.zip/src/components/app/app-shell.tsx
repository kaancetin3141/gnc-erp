'use client'

import { useEffect } from 'react'
import { useAppStore } from '@/store/app-store'
import { LoginScreen } from './login-screen'
import { Sidebar } from './sidebar'
import { Topbar } from './topbar'
import { CommandPalette } from './command-palette'
import { DashboardView } from '@/components/dashboard/dashboard-view'
import { CustomerList } from '@/components/customers/customer-list'
import { Customer360 } from '@/components/customers/customer-360'
import { LeadMiningView } from '@/components/maps/lead-mining-view'
import { KanbanBoard } from '@/components/pipeline/kanban-board'
import { TasksView } from '@/components/tasks/tasks-view'
import { ReportsView } from '@/components/reports/reports-view'
import { UsersView } from '@/components/users/users-view'
import { SettingsView } from '@/components/users/settings-view'
import { ProductsView } from '@/components/erp/products-view'
import { QuotesView } from '@/components/erp/quotes-view'
import { InvoicesView } from '@/components/erp/invoices-view'
import { OrdersView } from '@/components/erp/orders-view'
import { ProductionView } from '@/components/erp/production-view'
import { ChatView } from '@/components/chat/chat-view'
import { CafeView } from '@/components/cafe/cafe-view'
import { AdminPanel } from '@/components/admin/admin-panel'
import { hasPermission } from '@/lib/rbac'
import { Card } from '@/components/ui/card'
import { ShieldX } from 'lucide-react'
import { cn } from '@/lib/utils'

function NoPermission({ message }: { message: string }) {
  return (
    <div className="flex items-center justify-center min-h-[60vh] p-6">
      <Card className="p-8 max-w-md text-center">
        <div className="w-14 h-14 rounded-full bg-red-50 dark:bg-red-950/30 flex items-center justify-center mx-auto mb-4">
          <ShieldX className="w-7 h-7 text-red-500" />
        </div>
        <h3 className="font-semibold text-lg mb-2">Yetkisiz Erişim</h3>
        <p className="text-sm text-muted-foreground">{message}</p>
      </Card>
    </div>
  )
}

// Bir kullanıcı "kafe rolü" mü? (kasa/barmen/komi)
function isCafeRole(role: string) {
  return role === 'kasa' || role === 'barmen' || role === 'komi'
}

export function AppShell() {
  const { user, view, setView } = useAppStore()

  // PHOTO-PRODUCTION: Stock rolü için varsayılan ve tek görülebilen view 'production'
  // olmalı. Eğer stock rolündeki kullanıcı izinsiz bir view'a düşerse otomatik
  // üretim listesine yönlendir.
  // CAFE-ERP: Kafe rolleri (kasa/barmen/komi) için varsayılan view 'cafe'.
  useEffect(() => {
    if (user && user.role === 'stock' && view !== 'production') {
      setView('production')
    }
    if (user && isCafeRole(user.role) && view !== 'cafe') {
      setView('cafe')
    }
  }, [user, view, setView])

  if (!user) {
    return <LoginScreen />
  }

  // Stock rolü her zaman üretim listesini görür — persisted view ne olursa olsun.
  // Bu, dashboard gibi izin gerektiren view'lara stock rolünün düşmesini önler.
  if (user.role === 'stock') {
    return (
      <div className="flex h-screen overflow-hidden bg-background">
        <Sidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <Topbar />
          <main className="flex-1 overflow-y-auto custom-scroll">
            <div className={cn('p-4 lg:p-6 max-w-[1600px] mx-auto')}>
              <ProductionView />
            </div>
          </main>
        </div>
        <CommandPalette />
      </div>
    )
  }

  // Kafe rolleri her zaman kafe modülünü görür.
  if (isCafeRole(user.role)) {
    return (
      <div className="flex h-screen overflow-hidden bg-background">
        <Sidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <Topbar />
          <main className="flex-1 overflow-y-auto custom-scroll">
            <div className={cn('p-4 lg:p-6 max-w-[1600px] mx-auto')}>
              <CafeView />
            </div>
          </main>
        </div>
        <CommandPalette />
      </div>
    )
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar />
        <main className="flex-1 overflow-y-auto custom-scroll">
          <div className={cn('p-4 lg:p-6 max-w-[1600px] mx-auto')}>
            {view === 'dashboard' && <DashboardView />}
            {view === 'customers' && <CustomerList />}
            {view === 'customer-360' && <Customer360 />}
            {view === 'leads-maps' &&
              (hasPermission(user, 'maps.search') ? (
                <LeadMiningView />
              ) : (
                <NoPermission message="Potansiyel müşteri madenciliği için yetkiniz yok." />
              ))}
            {view === 'pipeline' &&
              (hasPermission(user, 'deals.manage') ? (
                <KanbanBoard />
              ) : (
                <NoPermission message="Fırsat pipeline'ını görüntüleme yetkiniz yok." />
              ))}
            {view === 'tasks' &&
              (hasPermission(user, 'tasks.view') ? (
                <TasksView />
              ) : (
                <NoPermission message="Görevleri görüntüleme yetkiniz yok." />
              ))}
            {view === 'chat' && <ChatView />}
            {view === 'reports' &&
              (hasPermission(user, 'reports.view') ? (
                <ReportsView />
              ) : (
                <NoPermission message="Raporları görüntüleme yetkiniz yok." />
              ))}
            {view === 'users' &&
              (hasPermission(user, 'users.manage') ? (
                <UsersView />
              ) : (
                <NoPermission message="Kullanıcı yönetimi için yetkiniz yok." />
              ))}
            {view === 'admin' &&
              (hasPermission(user, 'users.manage') ? (
                <AdminPanel />
              ) : (
                <NoPermission message="Admin paneli için yetkiniz yok." />
              ))}
            {view === 'settings' &&
              (hasPermission(user, 'settings.manage') ? (
                <SettingsView />
              ) : (
                <NoPermission message="Ayarları yönetme yetkiniz yok." />
              ))}
            {view === 'erp' &&
              (hasPermission(user, 'erp.manage') ? (
                <ProductsView />
              ) : (
                <NoPermission message="ERP modülü için yetkiniz yok." />
              ))}
            {view === 'quotes' &&
              (hasPermission(user, 'erp.manage') ? (
                <QuotesView />
              ) : (
                <NoPermission message="ERP modülü için yetkiniz yok." />
              ))}
            {view === 'invoices' &&
              (hasPermission(user, 'erp.manage') ? (
                <InvoicesView />
              ) : (
                <NoPermission message="ERP modülü için yetkiniz yok." />
              ))}
            {view === 'orders' &&
              (hasPermission(user, 'erp.manage') ? (
                <OrdersView />
              ) : (
                <NoPermission message="ERP modülü için yetkiniz yok." />
              ))}
            {view === 'production' &&
              (hasPermission(user, 'production.view') ? (
                <ProductionView />
              ) : (
                <NoPermission message="Üretim listesini görüntüleme yetkiniz yok." />
              ))}
            {view === 'cafe' &&
              (hasPermission(user, 'cafe.view') ? (
                <CafeView />
              ) : (
                <NoPermission message="Kafe modülü için yetkiniz yok." />
              ))}
          </div>
        </main>
      </div>
      <CommandPalette />
    </div>
  )
}
