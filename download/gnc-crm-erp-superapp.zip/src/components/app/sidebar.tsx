'use client'

import { useQuery } from '@tanstack/react-query'
import { useAppStore, type AppView } from '@/store/app-store'
import { hasPermission } from '@/lib/rbac'
import { apiGet } from '@/lib/api-client'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard, Users, MapPin, KanbanSquare, CheckSquare,
  BarChart3, UserCog, Settings, ChevronLeft, Sparkles, Boxes,
  FileText, Receipt, Package, MessageCircle, ClipboardCheck,
  ShieldCheck, Coffee,
} from 'lucide-react'
import type { PermissionKey } from '@/types'

interface NavItem {
  view: AppView
  label: string
  icon: typeof LayoutDashboard
  permission?: PermissionKey
  badge?: string
}

interface UnreadMessagesResponse {
  items: { id: string; isRead: boolean; receiverId: string }[]
  total: number
}

const NAV_ITEMS: { group: string; items: NavItem[] }[] = [
  {
    group: 'Genel',
    items: [
      { view: 'dashboard', label: 'Genel Bakış', icon: LayoutDashboard },
    ],
  },
  {
    group: 'Satış',
    items: [
      { view: 'customers', label: 'Müşteriler', icon: Users, permission: 'customers.view.own' },
      { view: 'leads-maps', label: 'Potansiyel Müşteri', icon: MapPin, permission: 'maps.search' },
      { view: 'pipeline', label: 'Fırsatlar', icon: KanbanSquare, permission: 'deals.manage' },
      { view: 'tasks', label: 'Görevler', icon: CheckSquare, permission: 'tasks.view' },
    ],
  },
  {
    group: 'İletişim',
    items: [
      { view: 'chat', label: 'Mesajlar', icon: MessageCircle },
    ],
  },
  {
    group: 'Analiz',
    items: [
      { view: 'reports', label: 'Raporlar', icon: BarChart3, permission: 'reports.view' },
    ],
  },
  {
    group: 'ERP',
    items: [
      { view: 'erp', label: 'Ürün & Stok', icon: Boxes, permission: 'erp.manage' },
      { view: 'quotes', label: 'Teklifler', icon: FileText, permission: 'erp.manage' },
      { view: 'invoices', label: 'Faturalar', icon: Receipt, permission: 'erp.manage' },
      { view: 'orders', label: 'Siparişler', icon: Package, permission: 'erp.manage' },
      { view: 'production', label: 'Üretim Listesi', icon: ClipboardCheck, permission: 'production.view' },
    ],
  },
  {
    group: 'Kafe',
    items: [
      { view: 'cafe', label: 'Kafe Yönetimi', icon: Coffee, permission: 'cafe.view' },
    ],
  },
  {
    group: 'Yönetim',
    items: [
      { view: 'admin', label: 'Admin Paneli', icon: ShieldCheck, permission: 'users.manage' },
      { view: 'users', label: 'Kullanıcılar', icon: UserCog, permission: 'users.manage' },
      { view: 'settings', label: 'Ayarlar', icon: Settings, permission: 'settings.manage' },
    ],
  },
]

export function Sidebar() {
  const { user, view, setView, sidebarCollapsed, toggleSidebar } = useAppStore()

  // Unread message count for badge
  const { data: unreadData } = useQuery({
    queryKey: ['unread-messages'],
    queryFn: () => apiGet<UnreadMessagesResponse>('/api/messages?unread=1&limit=100'),
    enabled: !!user,
    refetchInterval: 15_000,
  })

  const unreadCount = unreadData?.items?.length ?? 0

  if (!user) return null

  return (
    <>
      {/* Mobile overlay backdrop */}
      {!sidebarCollapsed && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={toggleSidebar}
        />
      )}
      <aside
        className={cn(
          'shrink-0 border-r border-border bg-sidebar flex flex-col transition-all duration-200',
          sidebarCollapsed ? 'w-[68px]' : 'w-60',
          // Mobile: fixed drawer, slide in/out
          'fixed lg:relative inset-y-0 left-0 z-50 lg:z-auto',
          sidebarCollapsed ? '-translate-x-full lg:translate-x-0' : 'translate-x-0',
        )}
      >
      {/* Logo */}
      <div className="h-16 flex items-center gap-2.5 px-4 border-b border-border">
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center font-bold text-white text-base shrink-0 shadow-sm">
          G
        </div>
        {!sidebarCollapsed && (
          <div className="min-w-0">
            <div className="font-bold text-sm tracking-tight leading-tight">GNC CRM</div>
            <div className="text-[10px] text-muted-foreground leading-tight truncate">{user.tenant.name}</div>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-5 custom-scroll">
        {NAV_ITEMS.map((group) => {
          let items = group.items.filter(
            (item) => !item.permission || hasPermission(user, item.permission),
          )
          // PHOTO-PRODUCTION (#2): depo rolü yalnızca Üretim Listesi'ni görür.
          // Diğer tüm modüller (müşteri, satış, ERP, mesajlaşma, ayarlar) gizlenir.
          // Fiyat/müşteri bilgisi sızıntısını önlemek için katı kısıtlama.
          if (user.role === 'stock') {
            items = items.filter((it) => it.view === 'production')
          }
          // CAFE-ERP: kafe rolleri (kasa/barmen/komi) sadece Kafe modülünü görür.
          // CRM/satış/ERP/yönetim modülleri gizlenir.
          if (user.role === 'kasa' || user.role === 'barmen' || user.role === 'komi') {
            items = items.filter((it) => it.view === 'cafe')
          }
          if (items.length === 0) return null
          return (
            <div key={group.group}>
              {!sidebarCollapsed && (
                <div className="px-3 mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
                  {group.group}
                </div>
              )}
              <div className="space-y-0.5">
                {items.map((item) => {
                  const isActive = view === item.view || (view === 'customer-360' && item.view === 'customers')
                  const isChat = item.view === 'chat'
                  const badgeCount = isChat ? unreadCount : 0
                  return (
                    <button
                      key={item.view}
                      onClick={() => { setView(item.view); if (window.innerWidth < 1024) toggleSidebar(); }}
                      title={sidebarCollapsed ? item.label : undefined}
                      className={cn(
                        'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all relative group',
                        isActive
                          ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                          : 'text-muted-foreground hover:text-sidebar-foreground hover:bg-sidebar-accent/50',
                      )}
                    >
                      {isActive && (
                        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 rounded-r-full bg-emerald-500" />
                      )}
                      <item.icon className={cn('w-[18px] h-[18px] shrink-0', isActive && 'text-emerald-600')} />
                      {!sidebarCollapsed && <span className="truncate flex-1 text-left">{item.label}</span>}
                      {badgeCount > 0 && (
                        <span
                          className={cn(
                            'shrink-0 min-w-[18px] h-[18px] px-1 rounded-full bg-emerald-600 text-white text-[10px] font-bold flex items-center justify-center',
                            sidebarCollapsed && 'absolute -top-0.5 -right-0.5 border-2 border-sidebar',
                          )}
                        >
                          {badgeCount > 99 ? '99+' : badgeCount}
                        </span>
                      )}
                    </button>
                  )
                })}
              </div>
            </div>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="border-t border-border p-2 space-y-1">
        {!sidebarCollapsed && hasPermission(user, 'erp.manage') && (
          <div className="px-3 py-2 mb-1 rounded-lg bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 border border-emerald-100 dark:border-emerald-900/50">
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400">ERP-lite Aktif</span>
            </div>
            <p className="text-[10px] text-muted-foreground leading-tight">Ürün, stok, teklif ve fatura yönetimi</p>
          </div>
        )}
        <button
          onClick={toggleSidebar}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-colors"
        >
          <ChevronLeft className={cn('w-[18px] h-[18px] shrink-0 transition-transform', sidebarCollapsed && 'rotate-180')} />
          {!sidebarCollapsed && <span>Daralt</span>}
        </button>
      </div>
      </aside>
    </>
  )
}
