'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { SessionUser } from '@/types'

export type AppView =
  | 'dashboard'
  | 'customers'
  | 'customer-360'
  | 'leads-maps'
  | 'pipeline'
  | 'tasks'
  | 'reports'
  | 'users'
  | 'settings'
  | 'erp'
  | 'quotes'
  | 'invoices'
  | 'orders'
  | 'chat'
  | 'production'
  | 'admin'
  | 'cafe'

interface AppState {
  // Session
  user: SessionUser | null
  sessionId: string | null
  setSession: (user: SessionUser | null, sessionId: string | null) => void
  logout: () => void

  // Navigation
  view: AppView
  setView: (view: AppView) => void
  selectedCustomerId: string | null
  selectedLeadId: string | null
  openCustomer: (id: string) => void
  openLead: (id: string) => void

  // Cafe ERP — seçili kafe (multi-cafe tenant'lar için)
  selectedCafeId: string | null
  setSelectedCafeId: (id: string | null) => void

  // Sidebar
  sidebarCollapsed: boolean
  toggleSidebar: () => void

  // Global command palette
  commandOpen: boolean
  setCommandOpen: (open: boolean) => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      user: null,
      sessionId: null,
      setSession: (user, sessionId) => set({ user, sessionId }),
      logout: () => set({ user: null, sessionId: null, view: 'dashboard', selectedCustomerId: null }),

      view: 'dashboard',
      setView: (view) => set({ view }),
      selectedCustomerId: null,
      selectedLeadId: null,
      openCustomer: (id) => set({ selectedCustomerId: id, view: 'customer-360' }),
      openLead: (id) => set({ selectedLeadId: id, view: 'leads-maps' }),

      selectedCafeId: null,
      setSelectedCafeId: (id) => set({ selectedCafeId: id }),

      sidebarCollapsed: false,
      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),

      commandOpen: false,
      setCommandOpen: (open) => set({ commandOpen: open }),
    }),
    {
      name: 'gnc-crm-store',
      partialize: (s) => ({
        user: s.user,
        sessionId: s.sessionId,
        view: s.view,
        sidebarCollapsed: s.sidebarCollapsed,
        selectedCafeId: s.selectedCafeId,
      }),
    },
  ),
)
