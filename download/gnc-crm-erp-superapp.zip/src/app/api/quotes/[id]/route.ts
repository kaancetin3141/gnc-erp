import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requireAuth, requirePermission, ok, err, getVisibilityFilter, safeJsonParse } from '@/lib/api-utils'
import { writeAuditLog } from '@/lib/auth'

// ============================================================
// Yardımcılar
// ============================================================

interface LineInput {
  id?: string
  productId?: string | null
  description?: string
  qty?: number | string
  unitPrice?: number | string
  taxRate?: number | string
}

function toNum(v: unknown, fallback = 0): number {
  if (typeof v === 'number') return isFinite(v) ? v : fallback
  if (typeof v === 'string') {
    const n = parseFloat(v)
    return isFinite(n) ? n : fallback
  }
  return fallback
}

function calcTotals(lines: LineInput[]) {
  let subtotal = 0
  let taxTotal = 0
  for (const l of lines) {
    const qty = toNum(l.qty, 1)
    const unitPrice = toNum(l.unitPrice, 0)
    const taxRate = toNum(l.taxRate, 0)
    const lineTotal = qty * unitPrice
    const lineTax = lineTotal * (taxRate / 100)
    subtotal += lineTotal
    taxTotal += lineTax
  }
  return {
    subtotal: Math.round(subtotal * 100) / 100,
    taxTotal: Math.round(taxTotal * 100) / 100,
    total: Math.round((subtotal + taxTotal) * 100) / 100,
  }
}

const QUOTE_STATUSES = ['taslak', 'gonderildi', 'onaylandi', 'reddedildi', 'faturalandi']

async function generateInvoiceNumber(tenantId: string): Promise<string> {
  const year = new Date().getFullYear()
  const count = await db.invoice.count({ where: { tenantId } })
  return `FAT-${year}-${String(count + 1).padStart(3, '0')}`
}

// ============================================================
// GET — tekil teklif
// ============================================================
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSession(req)
  const permErr = requirePermission(user, 'erp.manage')
  if (permErr) return permErr

  const { id } = await params
  const quote = await db.quote.findUnique({
    where: { id },
    include: {
      customer: {
        select: {
          id: true, name: true, segment: true, status: true,
          email: true, phone: true, address: true, city: true, taxNumber: true,
        },
      },
      lines: {
        include: { product: { select: { id: true, name: true, sku: true } } },
      },
      invoice: { select: { id: true, number: true, status: true } },
    },
  })

  if (!quote) return err('Teklif bulunamadı', 404)
  if (quote.tenantId !== user!.tenantId) return err('Erişim reddedildi', 403)

  return ok(quote)
}

// ============================================================
// PATCH — teklif güncelle (status, lines, dates, customer)
// ============================================================
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSession(req)
  const permErr = requirePermission(user, 'erp.manage')
  if (permErr) return permErr

  const { id } = await params
  const existing = await db.quote.findUnique({
    where: { id },
    include: { lines: true },
  })
  if (!existing) return err('Teklif bulunamadı', 404)
  if (existing.tenantId !== user!.tenantId) return err('Erişim reddedildi', 403)

  const body = await req.json()
  const {
    status, lines, customerId, currency, issueDate, validUntil, createInvoice,
  } = body as {
    status?: string
    lines?: LineInput[]
    customerId?: string
    currency?: string
    issueDate?: string
    validUntil?: string
    createInvoice?: boolean
  }

  const updateData: Record<string, unknown> = {}

  if (status && QUOTE_STATUSES.includes(status)) {
    updateData.status = status
  }
  if (customerId) {
    const cust = await db.customer.findUnique({ where: { id: customerId } })
    if (!cust || cust.tenantId !== user!.tenantId) {
      return err('Geçersiz müşteri', 400)
    }
    updateData.customerId = customerId
  }
  if (currency) updateData.currency = currency
  if (issueDate) updateData.issueDate = new Date(issueDate)
  if (validUntil !== undefined) {
    updateData.validUntil = validUntil ? new Date(validUntil) : null
  }

  // Kalemler güncelleniyorsa totals yeniden hesapla
  let newTotals: { subtotal: number; taxTotal: number; total: number } | null = null
  if (lines && Array.isArray(lines)) {
    newTotals = calcTotals(lines)
    updateData.subtotal = newTotals.subtotal
    updateData.taxTotal = newTotals.taxTotal
    updateData.total = newTotals.total
  }

  const updated = await db.quote.update({
    where: { id },
    data: updateData,
    include: {
      customer: { select: { id: true, name: true } },
      lines: { include: { product: { select: { id: true, name: true } } } },
    },
  })

  // Kalemleri güncelle (sil + yeniden oluştur en güvenli yaklaşım)
  if (lines && Array.isArray(lines)) {
    await db.quoteLine.deleteMany({ where: { quoteId: id } })
    if (lines.length > 0) {
      await db.quoteLine.createMany({
        data: lines.map((l) => ({
          quoteId: id,
          productId: l.productId || null,
          description: (l.description || '').trim(),
          qty: toNum(l.qty, 1),
          unitPrice: toNum(l.unitPrice, 0),
          taxRate: toNum(l.taxRate, 0),
          lineTotal: toNum(l.qty, 1) * toNum(l.unitPrice, 0),
        })),
      })
    }
  }

  await writeAuditLog({
    tenantId: user!.tenantId,
    actorId: user!.id,
    action: 'update',
    entity: 'quote',
    entityId: id,
    before: safeJsonParse(JSON.stringify(existing), null),
    after: safeJsonParse(JSON.stringify(updated), null),
  })

  // Opsiyonel: teklifi faturaya dönüştür
  let createdInvoice: unknown = null
  if (createInvoice && updated.status === 'faturalandi') {
    const number = await generateInvoiceNumber(user!.tenantId)
    const invoice = await db.invoice.create({
      data: {
        tenantId: user!.tenantId,
        customerId: updated.customerId,
        number,
        status: 'odeme_bekliyor',
        subtotal: updated.subtotal,
        taxTotal: updated.taxTotal,
        total: updated.total,
        currency: updated.currency,
        issueDate: new Date(),
        dueDate: null,
      },
    })
    await writeAuditLog({
      tenantId: user!.tenantId,
      actorId: user!.id,
      action: 'create',
      entity: 'invoice',
      entityId: invoice.id,
      after: safeJsonParse(JSON.stringify(invoice), null),
    })
    createdInvoice = invoice
  }

  return ok({ ...updated, createdInvoice })
}

// ============================================================
// DELETE — teklif sil (lines cascade)
// ============================================================
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSession(req)
  const permErr = requirePermission(user, 'erp.manage')
  if (permErr) return permErr

  const { id } = await params
  const existing = await db.quote.findUnique({ where: { id } })
  if (!existing) return err('Teklif bulunamadı', 404)
  if (existing.tenantId !== user!.tenantId) return err('Erişim reddedildi', 403)

  // Silmeden önce görünürlük kontrolü
  const visFilter = await getVisibilityFilter(user!)
  if (visFilter.ownerId) {
    const customer = await db.customer.findUnique({
      where: { id: existing.customerId },
      select: { ownerId: true },
    })
    if (customer && customer.ownerId && !visFilter.ownerId.in.includes(customer.ownerId)) {
      return err('Bu teklifi silme yetkiniz yok', 403)
    }
  }

  // QuoteLine cascade silinir (şema: onDelete: Cascade)
  await db.quote.delete({ where: { id } })

  await writeAuditLog({
    tenantId: user!.tenantId,
    actorId: user!.id,
    action: 'delete',
    entity: 'quote',
    entityId: id,
    before: safeJsonParse(JSON.stringify(existing), null),
  })

  return ok({ success: true })
}
