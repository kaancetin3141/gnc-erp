import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requirePermission, ok, err, getVisibilityFilter, safeJsonParse } from '@/lib/api-utils'
import { writeAuditLog } from '@/lib/auth'

// ============================================================
// Yardımcılar
// ============================================================

// Sipariş numarası üret: SIP-2025-001
async function generateOrderNumber(tenantId: string): Promise<string> {
  const year = new Date().getFullYear()
  const count = await db.order.count({ where: { tenantId } })
  return `SIP-${year}-${String(count + 1).padStart(3, '0')}`
}

const ORDER_STATUSES = ['hazirlaniyor', 'onaylandi', 'uretimde', 'sevk_yapildi', 'teslim_edildi', 'iptal']

// ============================================================
// GET — sipariş listesi
// ============================================================
export async function GET(req: NextRequest) {
  const user = await getSession(req)
  const permErr = requirePermission(user, 'erp.manage')
  if (permErr) return permErr

  // PRIVACY-TEMPLATES (#3): depo rolü sipariş listesini GÖREMEZ
  // (üretim listesi ayrı bir API ile yönetilir)
  if (user!.role === 'stock') {
    return ok({ items: [], total: 0, limit: 0, offset: 0 })
  }

  const url = new URL(req.url)
  const search = url.searchParams.get('search') || ''
  const status = url.searchParams.get('status') || ''
  const customerId = url.searchParams.get('customerId') || ''
  const limit = parseInt(url.searchParams.get('limit') || '200')
  const offset = parseInt(url.searchParams.get('offset') || '0')

  const visFilter = await getVisibilityFilter(user!)

  const where: Record<string, unknown> = {
    tenantId: user!.tenantId,
  }

  if (visFilter.ownerId) {
    where.customer = { ownerId: visFilter.ownerId }
  }

  if (search) {
    where.OR = [
      { number: { contains: search } },
      { customer: { name: { contains: search } } },
    ]
  }
  if (status) where.status = status
  if (customerId) where.customerId = customerId

  const [items, total] = await Promise.all([
    db.order.findMany({
      where,
      include: {
        customer: { select: { id: true, name: true, segment: true, status: true } },
        quote: { select: { id: true, number: true } },
        invoice: { select: { id: true, number: true, status: true } },
        _count: { select: { trackingSteps: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
    }),
    db.order.count({ where }),
  ])

  return ok({ items, total, limit, offset })
}

// ============================================================
// POST — yeni sipariş (manuel veya proforma/teklif bağlantılı)
// ============================================================
export async function POST(req: NextRequest) {
  const user = await getSession(req)
  const permErr = requirePermission(user, 'erp.manage')
  if (permErr) return permErr

  const body = await req.json()
  const {
    customerId, quoteId, invoiceId, totalAmount, currency,
    expectedDelivery, notes, status,
  } = body as {
    customerId?: string
    quoteId?: string
    invoiceId?: string
    totalAmount?: number | string
    currency?: string
    expectedDelivery?: string
    notes?: string
    status?: string
  }

  if (!customerId) return err('Müşteri seçimi gerekli', 400)

  const customer = await db.customer.findUnique({ where: { id: customerId } })
  if (!customer) return err('Müşteri bulunamadı', 404)
  if (customer.tenantId !== user!.tenantId) return err('Erişim reddedildi', 403)

  // Opsiyonel: teklif bağla
  let quoteData: { total: number; currency: string; number: string } | null = null
  if (quoteId) {
    const quote = await db.quote.findUnique({ where: { id: quoteId } })
    if (!quote) return err('Teklif bulunamadı', 404)
    if (quote.tenantId !== user!.tenantId) return err('Erişim reddedildi', 403)
    quoteData = { total: quote.total, currency: quote.currency, number: quote.number }
  }

  const finalStatus = status && ORDER_STATUSES.includes(status) ? status : 'hazirlaniyor'
  const finalAmount = totalAmount !== undefined ? Number(totalAmount) : (quoteData?.total ?? 0)
  const finalCurrency = currency || quoteData?.currency || user!.tenant.defaultCurrency || 'TRY'

  const number = await generateOrderNumber(user!.tenantId)

  const order = await db.order.create({
    data: {
      tenantId: user!.tenantId,
      customerId,
      quoteId: quoteId || null,
      invoiceId: invoiceId || null,
      number,
      status: finalStatus,
      totalAmount: isFinite(finalAmount) ? finalAmount : 0,
      currency: finalCurrency,
      orderDate: new Date(),
      expectedDelivery: expectedDelivery ? new Date(expectedDelivery) : null,
      notes: notes || null,
    },
    include: {
      customer: { select: { id: true, name: true } },
      trackingSteps: true,
    },
  })

  // İlk takip adımı
  await db.orderTrackingStep.create({
    data: {
      orderId: order.id,
      step: finalStatus,
      note: quoteData ? `Teklif ${quoteData.number} üzerinden oluşturuldu` : 'Manuel sipariş oluşturuldu',
      userId: user!.id,
    },
  })

  await writeAuditLog({
    tenantId: user!.tenantId,
    actorId: user!.id,
    action: 'create',
    entity: 'order',
    entityId: order.id,
    after: safeJsonParse(JSON.stringify(order), null),
  })

  return ok(order)
}
