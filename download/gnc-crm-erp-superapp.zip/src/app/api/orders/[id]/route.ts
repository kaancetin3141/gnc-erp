import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, requirePermission, ok, err, getVisibilityFilter, safeJsonParse } from '@/lib/api-utils'
import { writeAuditLog } from '@/lib/auth'

// ============================================================
// Yardımcılar
// ============================================================

const ORDER_STATUSES = ['hazirlaniyor', 'onaylandi', 'uretimde', 'sevk_yapildi', 'teslim_edildi', 'iptal']

// ============================================================
// GET — tekil sipariş (takip adımları dahil)
// ============================================================
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSession(req)
  const permErr = requirePermission(user, 'erp.manage')
  if (permErr) return permErr

  const { id } = await params
  const order = await db.order.findUnique({
    where: { id },
    include: {
      customer: {
        select: {
          id: true, name: true, segment: true, status: true,
          email: true, phone: true, address: true, city: true,
        },
      },
      quote: { select: { id: true, number: true, status: true, isProforma: true } },
      invoice: { select: { id: true, number: true, status: true } },
      trackingSteps: {
        orderBy: { createdAt: 'asc' },
      },
    },
  })

  if (!order) return err('Sipariş bulunamadı', 404)
  if (order.tenantId !== user!.tenantId) return err('Erişim reddedildi', 403)

  return ok(order)
}

// ============================================================
// PATCH — sipariş güncelle (status, expectedDelivery, notes)
// Durum değişince otomatik OrderTrackingStep oluştur
// ============================================================
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSession(req)
  const permErr = requirePermission(user, 'erp.manage')
  if (permErr) return permErr

  const { id } = await params
  const existing = await db.order.findUnique({
    where: { id },
    include: { trackingSteps: true },
  })
  if (!existing) return err('Sipariş bulunamadı', 404)
  if (existing.tenantId !== user!.tenantId) return err('Erişim reddedildi', 403)

  const body = await req.json()
  const { status, expectedDelivery, notes, note } = body as {
    status?: string
    expectedDelivery?: string | null
    notes?: string | null
    note?: string
  }

  const updateData: Record<string, unknown> = {}
  let trackingStep: { step: string; note: string | null } | null = null

  if (status && ORDER_STATUSES.includes(status) && status !== existing.status) {
    updateData.status = status
    if (status === 'teslim_edildi' && !existing.deliveredAt) {
      updateData.deliveredAt = new Date()
    }
    if (status === 'iptal' || status === 'hazirlaniyor') {
      updateData.deliveredAt = null
    }
    trackingStep = { step: status, note: note ?? null }
  }

  if (expectedDelivery !== undefined) {
    updateData.expectedDelivery = expectedDelivery ? new Date(expectedDelivery) : null
  }
  if (notes !== undefined) {
    updateData.notes = notes || null
  }

  const updated = await db.order.update({
    where: { id },
    data: updateData,
    include: {
      customer: { select: { id: true, name: true } },
      trackingSteps: { orderBy: { createdAt: 'asc' } },
    },
  })

  // Tracking adımı ekle
  if (trackingStep) {
    await db.orderTrackingStep.create({
      data: {
        orderId: id,
        step: trackingStep.step,
        note: trackingStep.note,
        userId: user!.id,
      },
    })

    // Sipariş 'uretimde' durumuna geçtiyse ve henüz üretim kalemleri yoksa,
    // fatura/teklif kalemlerinden üretim kalemlerini otomatik oluştur.
    if (trackingStep.step === 'uretimde') {
      const existingProdCount = await db.productionItem.count({
        where: { orderId: id, tenantId: user!.tenantId },
      })
      if (existingProdCount === 0) {
        const orderWithLines = await db.order.findUnique({
          where: { id },
          include: {
            quote: { include: { lines: { select: { productId: true, description: true, qty: true } } } },
            invoice: { include: { lines: { select: { productId: true, description: true, qty: true } } } },
          },
        })
        const sourceLines =
          (orderWithLines?.invoice?.lines?.length ?? 0) > 0
            ? orderWithLines!.invoice!.lines
            : orderWithLines?.quote?.lines ?? []
        if (sourceLines.length > 0) {
          await db.$transaction(
            sourceLines.map((line) =>
              db.productionItem.create({
                data: {
                  tenantId: user!.tenantId,
                  orderId: id,
                  productId: line.productId,
                  description: line.description,
                  qty: line.qty ?? 1,
                  status: 'bekliyor',
                },
              }),
            ),
          )
        }
      }
    }
  }

  await writeAuditLog({
    tenantId: user!.tenantId,
    actorId: user!.id,
    action: 'update',
    entity: 'order',
    entityId: id,
    before: safeJsonParse(JSON.stringify(existing), null),
    after: safeJsonParse(JSON.stringify(updated), null),
  })

  return ok(updated)
}

// ============================================================
// DELETE — sipariş sil (trackingSteps cascade)
// ============================================================
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSession(req)
  const permErr = requirePermission(user, 'erp.manage')
  if (permErr) return permErr

  const { id } = await params
  const existing = await db.order.findUnique({ where: { id } })
  if (!existing) return err('Sipariş bulunamadı', 404)
  if (existing.tenantId !== user!.tenantId) return err('Erişim reddedildi', 403)

  const visFilter = await getVisibilityFilter(user!)
  if (visFilter.ownerId) {
    const customer = await db.customer.findUnique({
      where: { id: existing.customerId },
      select: { ownerId: true },
    })
    if (customer && customer.ownerId && !visFilter.ownerId.in.includes(customer.ownerId)) {
      return err('Bu siparişi silme yetkiniz yok', 403)
    }
  }

  await db.order.delete({ where: { id } })

  await writeAuditLog({
    tenantId: user!.tenantId,
    actorId: user!.id,
    action: 'delete',
    entity: 'order',
    entityId: id,
    before: safeJsonParse(JSON.stringify(existing), null),
  })

  return ok({ success: true })
}
